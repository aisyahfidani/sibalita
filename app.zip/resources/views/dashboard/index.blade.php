@extends('layouts.app')


@section('content')
<div class="page-titles">
  <h2> {{ $pageTitle }} <small> {{ $pageNote }} </small></h2>
</div>

<div class="  ">


        <div class="row pb-4">
                    <div class="col-6 col-lg-4 mb-3">
                        <div class="card  ">
                            <div class="card-body">
                                <div class="d-flex">
                                    <div class="m-r-20 align-self-center">
                                        <i class="fas fa-leaf text-info" style="font-size: 40px;"></i>
                                    </div>
                                    <div class="align-self-center ">
                                        <h6 class=" m-t-10 m-b-0">Jumlah Balita Terdata</h6>
                                        <h2 class="m-t-0 "> {{ $dataBalita }} balita</h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-lg-4 mb-3">
                        <div class="card ">
                            <div class="card-body">
                                <div class="d-flex">
                                    <div class="m-r-20 align-self-center">
                                        <i class="fas fa-credit-card text-danger" style="font-size: 40px;"></i>
                                    </div>
                                    <div class="align-self-center">
                                        <h6 class="text-muted m-t-10 m-b-0">Jumlah Posyandu Terdaftar</h6>
                                        <h2 class="m-t-0">{{ $dataPosyandu }} posyandu</h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-lg-4 mb-3">
                        <div class="card ">
                            <div class="card-body ">
                                <div class="d-flex">
                                    <div class="m-r-20 align-self-center">
                                        <i class="icon-badge text-primary" style="font-size: 40px;"></i>
                                    </div>
                                    <div class="align-self-center">
                                        <h6 class=" m-t-10 m-b-0">Total Balita Stunting</h6>
                                        <h2 class="m-t-0">{{ $dataStunting }} Balita</h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <!-- ============================================================== -->
                <!-- Sales overview chart -->
                <!-- ============================================================== -->
                <!--<div class="row pb-4">-->
                <!--    <div class="col-lg-9 col-md-12">-->
                <!--        <div class="card">-->
                <!--            <div class="card-body">-->
                <!--                <div class="d-flex no-block">-->
                <!--                    <div>-->
                <!--                        <h3 class="card-title m-b-5"><span class="lstick"></span>Balita terdata di masing-masing desa </h3>-->
                <!--                    </div>-->
                <!--                    <div class="ml-auto">-->
                <!--                        <select class="custom-select b-0">-->
                <!--                            <option selected="11">November 2023</option>-->
                <!--                            <option value="10">Oktober 2023</option>-->
                <!--                            <option value="9">September 2023</option>-->
                <!--                            <option value="8">Agustus 2023</option>-->
                <!--                        </select>-->
                <!--                    </div>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--            <div class="card-body">-->
                <!--                <div id="chartdiv" class="p-relative" style="height:360px;"></div>-->
                <!--            </div>-->
                            
                            
                <!--        </div>-->
                <!--    </div>-->
                    <!-- ============================================================== -->
                    <!-- visit charts-->
                    <!-- ============================================================== -->
                <!--    <div class="col-lg-3 col-md-12">-->
                <!--        <div class="card">-->
                <!--            <div class="card-body">-->
                <!--                <h4 class="card-title"><span class="lstick"></span>Visit Separation</h4>-->
                <!--                <div id="chartContainer" style="height: 370px; width: 100%;"></div>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->


                    

</div>
<?php
 
$dataPoints = array( 
	array("label"=>"Denanyar", "y"=>6),
	array("label"=>"Plosogeneng", "y"=>12),
	array("label"=>"Banjardowo", "y"=>8 ),
	array("label"=>"Sumberjo", "y"=>6),
	array("label"=>"Pulo lor", "y"=>4)
)
 
?>
<script>
window.onload = function() {
 
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		text: "Jumlah Balita Stunting"
	},
	subtitles: [{
		text: "November 2023"
	}],
	data: [{
		type: "pie",
		yValueFormatString: "#",
		indexLabel: "{label} ({y})",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
}
</script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/highcharts-more.js"></script>
<script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>
<script type="text/javascript">
  // Data retrieved from http://vikjavev.no/ver/index.php?spenn=2d&sluttid=16.06.2015.
$(function () {
    Highcharts.chart('chartdiv', {
    chart: {
        type: 'areaspline'
    },
    title: {
        text: 'Data Statistik'
    },
    legend: {
        layout: 'vertical',
        align: 'left',
        verticalAlign: 'top',
        x: 150,
        y: 100,
        floating: true,
        borderWidth: 1,
        backgroundColor:
            Highcharts.defaultOptions.legend.backgroundColor || '#FFFFFF'
    },
    xAxis: {
        categories: [
            'Jan',
            'Feb',
            'Mar',
            'Apr',
            'Mei',
            'Jun',,
            'Jul',
            'Agt',
            'Sep',
            'Okt',
            'Nov',
            'Des'
        ],
        plotBands: [{ // visualize the weekend
            from: 4.5,
            to: 6.5,
            color: 'rgba(68, 170, 213, .2)'
        }]
    },
    yAxis: {
        title: {
            text: 'Jumlah Balita'
        }
    },
    tooltip: {
        shared: true,
        valueSuffix: ' Orang'
    },
    credits: {
        enabled: false
    },
    plotOptions: {
        areaspline: {
            fillOpacity: 0.5
        }
    },
    series: [{
        name: 'Stunting',
        data: [3, 4, 3, 5, 4, 10, 12]
    }, {
        name: 'Ideal',
        data: [1, 3, 4, 3, 3, 5, 4]
    }
    , {
        name: 'Lebih',
        data: [4, 5,1, 6, 12, 3, 1]
    }]
});

});



</script>            
@stop