<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="shortcut icon" href="{{ asset('favicon.ico')}}" type="image/x-icon">
    <title>{{ config('sximo.cnf_appname') }}</title>
    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />

    <link href="{{ asset('')}}assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="{{ asset('')}}assets/plugins/perfect-scrollbar/dist/css/perfect-scrollbar.min.css" rel="stylesheet">
    <!-- This page CSS -->
    <!--c3 CSS -->
    
    <link href="{{ asset('')}}assets/plugins/c3-master/c3.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="{{ asset('')}}assets/css/style.css" rel="stylesheet">
    <!-- Dashboard 1 Page CSS -->
    <link href="{{ asset('')}}assets/css/legacy.css" rel="stylesheet">
    <!-- You can change the theme colors from here -->
    <link href="{{ asset('')}}assets/css/colors/colors.css" id="themes" rel="stylesheet">
    <!--Toaster Popup message CSS -->
    <link href="{{ asset('')}}assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
  <link href="{{ asset('')}}assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet">





    <script src="{{ asset('')}}assets/plugins/moment/moment.js"></script>
    <script src="{{ asset('')}}assets/js/sximo.min.js"></script>
    <!-- Bootstrap popper Core JavaScript -->
    <script src="{{ asset('')}}assets/plugins/bootstrap/js/popper.min.js"></script>
    <script src="{{ asset('')}}assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="{{ asset('')}}assets/js/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <script src="{{ asset('')}}assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="{{ asset('')}}assets/js/sidebarmenu.js"></script>
<!--stickey kit -->
    <script src="{{ asset('')}}assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="{{ asset('')}}assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="{{ asset('')}}assets/js/custom.min.js"></script>
   
    <!--c3 JavaScript 
    <script src="{{ asset('')}}assets/plugins/d3/d3.min.js"></script>
    <script src="{{ asset('')}}assets/plugins/c3-master/c3.min.js"></script> --> 
     <script src="{{ asset('')}}assets/js/sximo5.js"></script>
     <script src="{{ asset('')}}assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
    <!-- Chart JS -->
   
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->

</head>

<body class="fix-header fix-sidebar  light-theme  ">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label"> {{ config('sximo.cnf_appname') }} </p>
        </div>
    </div>
		<div class="row pb-12">
		    <div class="col-lg-9 col-md-12">
		        <div class="card">
		            <div class="card-body">
		                <div id="chartdiv" class="p-relative" style="height:360px;"></div>
		            </div>
		            <div class="row" style="padding-left:50px; padding-bottom:20px;">
		<b style="font-size:14px;">Keterangan :</b>

			<div class="col-md-2" style="font-size:10px;">
				Usia 1 bulan: 3,4—5,1 kg. <br>
				Usia 2 bulan: 4,3—6,3 kg.<br>
				Usia 3 bulan: 5,0—7,2 kg.<br>
				Usia 4 bulan: 5,6—7,8 kg.<br>
				Usia 5 bulan: 6,0—8,4 kg.<br>
				
			</div>
			<div class="col-md-2" style="font-size:10px;">
				Usia 6 bulan: 6,4—8,8 kg.<br>
				Usia 7 bulan: 6,7—9,2 kg.<br>
				Usia 8 bulan: 6,9—9,6 kg.<br>
				Usia 9 bulan: 7,1—9,9 kg.<br>
				Usia 10 bulan: 7,4—10,2 kg.<br>
			</div>
			<div class="col-md-2" style="font-size:10px;">
				3 tahun: 11,3–18,3 kg<br>
				3 tahun, 6 bulan: 12–19,7 kg<br>
				4 tahun: 12,7–21,2 kg<br>
				4 tahun, 6 bulan: 13,4–22,7 kg<br>
				5 tahun: 14,1–24,2 kg<br>

			</div>
			<div class="col-md-2" style="font-size:10px;">
				Usia 11 bulan: 7,6—10,5 kg.<br>
				1 tahun: 7,7–12 kg<br>
				1 tahun, 6 bulan: 8,8–13,7 kg<br>
				2 tahun: 9,7–15,3 kg<br>
				2 tahun, 6 bulan: 10,5–16,9 kg<br>
			</div>
			<div class="col-md-2" style="font-size:10px;">

				3 tahun: 11,3–18,3 kg<br>
				3 tahun, 6 bulan: 12–19,7 kg<br>
				4 tahun: 12,7–21,2 kg<br>
				4 tahun, 6 bulan: 13,4–22,7 kg<br>
				5 tahun: 14,1–24,2 kg<br>

			</div>
		</div>
		        </div>
		    </div>
		</div>
		
</body>


<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/highcharts-more.js"></script>

<script type="text/javascript">
  // Data retrieved from http://vikjavev.no/ver/index.php?spenn=2d&sluttid=16.06.2015.
$(function () {
    Highcharts.chart('chartdiv', {
    chart: {
        type: 'line'
    },
    title: {
        text: 'NAMA BALITA : {{ strtoupper($cekDataBalita[0]->nama_balita) }}'
    },
    legend: {
        layout: 'vertical',
        align: 'left',
        verticalAlign: 'top',
        x: 150,
        y: 100,
        floating: true,
        borderWidth: 1,
        backgroundColor:
            Highcharts.defaultOptions.legend.backgroundColor || '#FFFFFF'
    },
    xAxis: {title: {
        text: "# Data ke" },
        categories: [
            
        ],
        plotBands: [{ // visualize the weekend
            from: 4.5,
            to: 6.5,
            color: 'rgba(68, 170, 213, .2)'
        }]
    },
    yAxis: {
        title: {
            text: 'Statistic Balita'
        }
    },
    tooltip: {
        shared: true,
        valueSuffix: ' '
    },
    credits: {
        enabled: false
    },
    plotOptions: {
        areaspline: {
            fillOpacity: 0.5
        }
    },
    series: [{
        name: 'Umur Balita',
        data: {{ json_encode($cekDataUmurBalita,JSON_NUMERIC_CHECK) }}
    },{
    	name: 'Berat Balita',
        data: {{ json_encode($cekDataBeratBalita,JSON_NUMERIC_CHECK) }}
    }, {
    	name: 'Tinggi Balita',
        data: {{ json_encode($cekDataTinggiBalita,JSON_NUMERIC_CHECK) }}
    }]
});

});



</script>   
</html>

          