@extends('layouts.app')

@section('content')
<div class="page-titles">
  <h2> {{ $pageTitle }} <small> {{ $pageNote }} </small></h2>
</div>
<div class="card">
	<div class="card-body">


	{!! Form::open(array('url'=>'databalita?return='.$return, 'class'=>'form-horizontal  validated sximo-form','files' => true ,'id'=> 'FormTable' )) !!}
	<div class="toolbar-nav">
		<div class="row">
			<div class="col-md-6 " >
				 <a href="{{ url($pageModule.'?return='.$return) }}" class="tips btn btn-danger  btn-sm "  title="{{ __('core.btn_back') }}" ><i class="fa  fa-times"></i></a>
			</div>
			<div class="col-md-6  text-right " >
				<div class="btn-group">
					
						<button name="apply" class="tips btn btn-sm btn-info  "  title="{{ __('core.btn_back') }}" > {{ __('core.sb_apply') }} </button>
						<button name="save" class="tips btn btn-sm btn-primary "  id="saved-button" title="{{ __('core.btn_back') }}" > {{ __('core.sb_save') }} </button> 
						
					
				</div>		
			</div>
			
		</div>
	</div>	


	
	<ul class="parsley-error-list">
		@foreach($errors->all() as $error)
			<li>{{ $error }}</li>
		@endforeach
	</ul>		
	<div class="">
		<div class="col-md-12">
						<fieldset><legend> Data Balita</legend>
				{!! Form::hidden('id', $row['id']) !!}					
									  <div class="form-group row  " >
										<label for="Nama Desa" class=" control-label col-md-4 "> Nama Desa </label>
										<div class="col-md-8">
										  <select name='nama_desa' rows='5' id='nama_desa' class='select2 '   ></select> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Nama Posyandu" class=" control-label col-md-4 "> Nama Posyandu </label>
										<div class="col-md-8">
										  <select name='nama_posyandu' rows='5' id='nama_posyandu' class='select2 '   ></select> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Nama Balita" class=" control-label col-md-4 "> Nama Balita </label>
										<div class="col-md-8">
										  <input  type='text' name='nama_balita' id='nama_balita' value='{{ $row['nama_balita'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Tanggal Lahir" class=" control-label col-md-4 "> Tanggal Lahir </label>
										<div class="col-md-8">
										  <input  type='text' name='tanggal_lahir' id='tanggal_lahir' value='{{ $row['tanggal_lahir'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Umur Balita" class=" control-label col-md-4 "> Umur Balita </label>
										<div class="col-md-8">
										  <input  type='text' name='umur_balita' id='umur_balita' value='{{ $row['umur_balita'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Berat Balita" class=" control-label col-md-4 "> Berat Balita </label>
										<div class="col-md-8">
										  <input  type='text' name='berat_balita' id='berat_balita' value='{{ $row['berat_balita'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Tinggi Badan Balita" class=" control-label col-md-4 "> Tinggi Badan Balita </label>
										<div class="col-md-8">
										  <input  type='text' name='tinggi_badan_balita' id='tinggi_badan_balita' value='{{ $row['tinggi_badan_balita'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> </fieldset></div>

	</div>
	
	<input type="hidden" name="action_task" value="save" />
	{!! Form::close() !!}
	</div>
</div>
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		
		$("#nama_desa").jCombo("{!! url('databalita/comboselect?filter=data_desa:id:nama_desa') !!}",
		{  selected_value : '{{ $row["nama_desa"] }}' });
		
		$("#nama_posyandu").jCombo("{!! url('databalita/comboselect?filter=v_posyandu:id:first_name|last_name') !!}",
		{  selected_value : '{{ $row["nama_posyandu"] }}' });
		 	
		 	 

		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("databalita/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
@stop