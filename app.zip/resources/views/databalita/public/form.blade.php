

		 {!! Form::open(array('url'=>'databalita', 'class'=>'form-horizontal','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}

	@if(Session::has('messagetext'))
	  
		   {!! Session::get('messagetext') !!}
	   
	@endif
	<ul class="parsley-error-list">
		@foreach($errors->all() as $error)
			<li>{{ $error }}</li>
		@endforeach
	</ul>		


<div class="col-md-12">
						<fieldset><legend> Data Balita</legend>
				{!! Form::hidden('id', $row['id']) !!}					
									  <div class="form-group row  " >
										<label for="Nama Desa" class=" control-label col-md-4 "> Nama Desa </label>
										<div class="col-md-8">
										  <select name='nama_desa' rows='5' id='nama_desa' class='select2 '   ></select> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Nama Posyandu" class=" control-label col-md-4 "> Nama Posyandu </label>
										<div class="col-md-8">
										  <select name='nama_posyandu' rows='5' id='nama_posyandu' class='select2 '   ></select> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Nama Balita" class=" control-label col-md-4 "> Nama Balita </label>
										<div class="col-md-8">
										  <input  type='text' name='nama_balita' id='nama_balita' value='{{ $row['nama_balita'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Umur Balita" class=" control-label col-md-4 "> Umur Balita </label>
										<div class="col-md-8">
										  <input  type='text' name='umur_balita' id='umur_balita' value='{{ $row['umur_balita'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Berat Balita" class=" control-label col-md-4 "> Berat Balita </label>
										<div class="col-md-8">
										  <input  type='text' name='berat_balita' id='berat_balita' value='{{ $row['berat_balita'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Tinggi Badan Balita" class=" control-label col-md-4 "> Tinggi Badan Balita </label>
										<div class="col-md-8">
										  <input  type='text' name='tinggi_badan_balita' id='tinggi_badan_balita' value='{{ $row['tinggi_badan_balita'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> </fieldset></div>

			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-default btn-sm" ><i class="fa  fa-check-circle"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-default btn-sm" ><i class="fa  fa-save "></i> {{ Lang::get('core.sb_save') }}</button>
				  </div>	  
			
		</div> 
		 <input type="hidden" name="action_task" value="public" />
		 {!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		$("#nama_desa").jCombo("{!! url('databalita/comboselect?filter=data_desa:id:nama_desa') !!}",
		{  selected_value : '{{ $row["nama_desa"] }}' });
		
		$("#nama_posyandu").jCombo("{!! url('databalita/comboselect?filter=nama_posyandu:id:nama_posyandu') !!}",
		{  selected_value : '{{ $row["nama_posyandu"] }}' });
		 

		$('.removeCurrentFiles').on('click',function(){
			var removeUrl = $(this).attr('href');
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
