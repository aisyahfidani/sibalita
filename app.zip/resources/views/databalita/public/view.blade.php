<div class="container" class="pt-3 pb-3">
    <div class="row m-b-lg animated fadeInDown delayp1 text-center">
        <h3> {{ $pageTitle }} <small> {{ $pageNote }} </small></h3>
        <hr />       
    </div>
</div>
<div class="m-t">
	<div class="table-container" > 	

		<table class="table table-striped table-bordered" >
			<tbody>	
		
			
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Nama Desa', (isset($fields['nama_desa']['language'])? $fields['nama_desa']['language'] : array())) }}</td>
						<td>{{ SiteHelpers::formatLookUp($row->nama_desa,'nama_desa','1:data_desa:id:nama_desa') }} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Nama Posyandu', (isset($fields['nama_posyandu']['language'])? $fields['nama_posyandu']['language'] : array())) }}</td>
						<td>{{ SiteHelpers::formatLookUp($row->nama_posyandu,'nama_posyandu','1:nama_posyandu:id:nama_posyandu') }} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Nama Balita', (isset($fields['nama_balita']['language'])? $fields['nama_balita']['language'] : array())) }}</td>
						<td>{{ $row->nama_balita}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Umur Balita', (isset($fields['umur_balita']['language'])? $fields['umur_balita']['language'] : array())) }}</td>
						<td>{{ $row->umur_balita}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Berat Balita', (isset($fields['berat_balita']['language'])? $fields['berat_balita']['language'] : array())) }}</td>
						<td>{{ $row->berat_balita}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Tinggi Badan Balita', (isset($fields['tinggi_badan_balita']['language'])? $fields['tinggi_badan_balita']['language'] : array())) }}</td>
						<td>{{ $row->tinggi_badan_balita}} </td>
						
					</tr>
						
					<tr>
						<td width='30%' class='label-view text-right'></td>
						<td> <a href="javascript:history.go(-1)"> Back To Grid <a> </td>
						
					</tr>					
				
			</tbody>	
		</table>   

	 
	
	</div>
</div>	