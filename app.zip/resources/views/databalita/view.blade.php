@extends('layouts.app')

@section('content')
<div class="page-titles">
  <h2> {{ $pageTitle }} <small> {{ $pageNote }} </small></h2>
</div>
<div class="card">
	<div class="card-body">

		<div class="toolbar-nav">
			<div class="row">
				<div class="col-md-6 ">
					<div class="btn-group">
						<a href="{{ url('databalita?return='.$return) }}" class="tips btn btn-danger  btn-sm  " title="{{ __('core.btn_back') }}"><i class="fa  fa-times"></i></a>		
						@if($access['is_add'] ==1)
				   		<a href="{{ url('databalita/'.$id.'/edit?return='.$return) }}" class="tips btn btn-info btn-sm  " title="{{ __('core.btn_edit') }}"><i class="icon-note"></i></a>
						@endif
					</div>	
				</div>
				<div class="col-md-6 text-right">			
					<div class="btn-group">
				   		<a href="{{ ($prevnext['prev'] != '' ? url('databalita/'.$prevnext['prev'].'?return='.$return ) : '#') }}" class="tips btn btn-primary  btn-sm"><i class="fa fa-arrow-left"></i>  </a>	
						<a href="{{ ($prevnext['next'] != '' ? url('databalita/'.$prevnext['next'].'?return='.$return ) : '#') }}" class="tips btn btn-primary btn-sm "> <i class="fa fa-arrow-right"></i>  </a>			
					</div>			
				</div>	

				
				
			</div>
		</div>
	
		<div class="table-responsive">
			<table class="table  table-bordered " >
				<tbody>	
			
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Nama Desa', (isset($fields['nama_desa']['language'])? $fields['nama_desa']['language'] : array())) }}</td>
						<td>{{ $row->nama_desa}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Nama Posyandu', (isset($fields['nama_posyandu']['language'])? $fields['nama_posyandu']['language'] : array())) }}</td>
						<td>{{ $row->nama_posyandu}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Nama Balita', (isset($fields['nama_balita']['language'])? $fields['nama_balita']['language'] : array())) }}</td>
						<td>{{ $row->nama_balita}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Tanggal Lahir', (isset($fields['tanggal_lahir']['language'])? $fields['tanggal_lahir']['language'] : array())) }}</td>
						<td>{{ $row->tanggal_lahir}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Umur Balita', (isset($fields['umur_balita']['language'])? $fields['umur_balita']['language'] : array())) }}</td>
						<td>{{ MyHelpers::umurBalita($row->umur_balita) }} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Berat Balita', (isset($fields['berat_balita']['language'])? $fields['berat_balita']['language'] : array())) }}</td>
						<td>{{ MyHelpers::beratBalita($row->berat_balita) }} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Tinggi Badan Balita', (isset($fields['tinggi_badan_balita']['language'])? $fields['tinggi_badan_balita']['language'] : array())) }}</td>
						<td>{{ MyHelpers::tinggiBalita($row->tinggi_badan_balita) }} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Catatan Tambahan', (isset($fields['catatan_tambahan']['language'])? $fields['catatan_tambahan']['language'] : array())) }}</td>
						<td>{{ $row->catatan_tambahan}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Bbu', (isset($fields['bbu']['language'])? $fields['bbu']['language'] : array())) }}</td>
						<td>{{ $row->bbu}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Pbu', (isset($fields['pbu']['language'])? $fields['pbu']['language'] : array())) }}</td>
						<td>{{ $row->pbu}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Bbpb', (isset($fields['bbpb']['language'])? $fields['bbpb']['language'] : array())) }}</td>
						<td>{{ $row->bbpb}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Kategori Balita', (isset($fields['kategori_balita']['language'])? $fields['kategori_balita']['language'] : array())) }}</td>
						<td>{{ $row->kategori_balita}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Created At', (isset($fields['created_at']['language'])? $fields['created_at']['language'] : array())) }}</td>
						<td>{{ $row->created_at}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Updated At', (isset($fields['updated_at']['language'])? $fields['updated_at']['language'] : array())) }}</td>
						<td>{{ $row->updated_at}} </td>
						
					</tr>
				
				</tbody>	
			</table>   

		 	

		</div>
			
	</div>
</div>		
@stop
