@extends('layouts.app')

@section('content')
<div class="page-titles">
  <h2> {{ $pageTitle }} <small> {{ $pageNote }} </small></h2>
</div>
<div class="card">
	<div class="card-body">


	{!! Form::open(array('url'=>'databalita?return='.$return, 'class'=>'form-horizontal  validated sximo-form','files' => true ,'id'=> 'FormTable' )) !!}
	<div class="toolbar-nav">
		<div class="row">
			<div class="col-md-6 " >
				 <a href="{{ url($pageModule.'?return='.$return) }}" class="tips btn btn-danger  btn-sm "  title="{{ __('core.btn_back') }}" ><i class="fa  fa-times"></i></a>
			</div>
			<div class="col-md-6  text-right " >
				<div class="btn-group">
					
						<button name="apply" class="tips btn btn-sm btn-info  "  title="{{ __('core.btn_back') }}" > {{ __('core.sb_apply') }} </button>
						<button name="save" class="tips btn btn-sm btn-primary "  id="saved-button" title="{{ __('core.btn_back') }}" > {{ __('core.sb_save') }} </button> 
						
					
				</div>		
			</div>
			
		</div>
	</div>	


	
	<ul class="parsley-error-list">
		@foreach($errors->all() as $error)
			<li>{{ $error }}</li>
		@endforeach
	</ul>		
	<div class="">
		<div class="col-md-12">
						<fieldset><legend> Data Balita</legend>
				{!! Form::hidden('id', $row['id']) !!}					
									  <div class="form-group row  " >
										<label for="Nama Desa" class=" control-label col-md-4 "> Nama Desa </label>
										<div class="col-md-8">
										  <select name='nama_desa' rows='5' id='nama_desa' class='select2 '   ></select> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Nama Posyandu" class=" control-label col-md-4 "> Nama Posyandu </label>
										<div class="col-md-8">
										  <select name='nama_posyandu' rows='5' id='nama_posyandu' class='select2 '   ></select> 
										 </div> 
										 
									  </div> {!! Form::hidden('nama_bidan', $row['nama_bidan']) !!}					
									  <div class="form-group row  " >
										<label for="Nama Balita" class=" control-label col-md-4 "> Nama Balita </label>
										<div class="col-md-8">
										  <input  type='text' name='nama_balita' id='nama_balita' value='{{ $row['nama_balita'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Tanggal Lahir" class=" control-label col-md-4 "> Tanggal Lahir </label>
										<div class="col-md-8">
										  <div class="form-row">
                                                  <input type="hidden" name="tanggal_lahir" id="tanggal_lahir">
                                              <div class="col">
                                                <select name="tanggal" id="tanggal" class="form-control form-control-sm">
                                                  <option value="">Tanggal</option>
                                                  @for ($i = 1; $i <= 31; $i++)
                                                    <option value="{{ $i }}" {{ (old('tanggal', date('j', strtotime($row['tanggal_lahir']))) == $i) ? 'selected' : '' }}>{{ $i }}</option>
                                                  @endfor
                                                </select>
                                              </div> -
                                            
                                              <div class="col">
                                                <?php
                                                  $bulanIndo = [
                                                1 => 'Januari',
                                                2 => 'Februari',
                                                3 => 'Maret',
                                                4 => 'April',
                                                5 => 'Mei',
                                                6 => 'Juni',
                                                7 => 'Juli',
                                                8 => 'Agustus',
                                                9 => 'September',
                                                10 => 'Oktober',
                                                11 => 'November',
                                                12 => 'Desember'
                                              ];
                                              ?>
                                              
                                             <select name="bulan" id="bulan" class="form-control form-control-sm">
                                              <option value="">Bulan</option>
                                              @for ($i = 1; $i <= 12; $i++)
                                                <option value="{{ $i }}" {{ (old('bulan', date('n', strtotime($row['tanggal_lahir']))) == $i) ? 'selected' : '' }}>
                                                  {{ $bulanIndo[$i] }}
                                                </option>
                                              @endfor
                                            </select>
                                              </div> -
                                            
                                              <div class="col">
                                                <select name="tahun" id="tahun" class="form-control form-control-sm">
                                                  <option value="">Tahun</option>
                                                  @for ($i = date('Y'); $i >= 1900; $i--)
                                                    <option value="{{ $i }}" {{ (old('tahun', date('Y', strtotime($row['tanggal_lahir']))) == $i) ? 'selected' : '' }}>{{ $i }}</option>
                                                  @endfor
                                                </select>
                                              </div>
                                            </div>
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Jenis Kelamin" class=" control-label col-md-4 "> Jenis Kelamin </label>
										<div class="col-md-8">
										    
										    <input type='radio' name='jenis_kelamin' value ='laki-laki' required @if($row['jenis_kelamin'] == 'laki-laki') checked="checked" @endif class="filled-in" id="laki-laki">  <label for="laki-laki"> Laki-laki </label>  
                                            <input type='radio' name='jenis_kelamin' value ='perempuan' required @if($row['jenis_kelamin'] == 'perempuan') checked="checked" @endif class="filled-in" id="perempuan">  <label for="perempuan"> perempuan </label>
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Umur Balita" class=" control-label col-md-4 "> Umur Balita *<small>(Bulan)</small> </label>
										<div class="col-md-8">
										  <input  type='text' name='umur_balita' id='umur_balita' value='{{ $row['umur_balita'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Berat Balita" class=" control-label col-md-4 "> Berat Balita *<small>(Kg)</small></label>
										<div class="col-md-8">
										  <input  type='text' name='berat_balita' id='berat_balita' value='{{ $row['berat_balita'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Tinggi Badan Balita" class=" control-label col-md-4 "> Tinggi Badan Balita *<small>(Cm)</small></label>
										<div class="col-md-8">
										  <input  type='text' name='tinggi_badan_balita' id='tinggi_badan_balita' value='{{ $row['tinggi_badan_balita'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> {!! Form::hidden('bbu', $row['bbu']) !!}{!! Form::hidden('pbu', $row['pbu']) !!}{!! Form::hidden('bbpb', $row['bbpb']) !!}{!! Form::hidden('kategori_balita', $row['kategori_balita']) !!}</fieldset></div>

	</div>
	
	<input type="hidden" name="action_task" value="save" />
	{!! Form::close() !!}
	</div>
</div>
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		
		$("#nama_desa").jCombo("{!! url('databalita/comboselect?filter=data_desa:nama_desa:nama_desa') !!}",
		{  selected_value : '{{ $row["nama_desa"] }}' });
		
		$("#nama_posyandu").jCombo("{!! url('databalita/comboselect?filter=posyandu:nama_posyandu:nama_posyandu') !!}",
		{  selected_value : '{{ $row["nama_posyandu"] }}' });
		 	
		 	 

		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("databalita/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});	
		
		
		
	});
	</script>
	<script>
      function hitungUmur() {
        const tgl = document.getElementById('tanggal').value;
        const bln = document.getElementById('bulan').value;
        const thn = document.getElementById('tahun').value;
    
        if (tgl && bln && thn) {
          const tanggalLahir = new Date(thn, bln - 1, tgl);
          const hariIni = new Date();
    
          let tahun = hariIni.getFullYear() - tanggalLahir.getFullYear();
          let bulan = hariIni.getMonth() - tanggalLahir.getMonth();
          let hari = hariIni.getDate() - tanggalLahir.getDate();
    
          // Penyesuaian jika tanggal hari belum lewat dalam bulan ini
          if (hari < 0) {
            bulan -= 1;
          }
    
          let umurDalamBulan = tahun * 12 + bulan;
    
          // Pastikan umur tidak negatif
          if (umurDalamBulan < 0) umurDalamBulan = 0;
    
          document.getElementById('umur_balita').value = umurDalamBulan;
        }
      }
    
      document.addEventListener('DOMContentLoaded', function () {
        ['tanggal', 'bulan', 'tahun'].forEach(function (id) {
          const el = document.getElementById(id);
          if (el) {
            el.addEventListener('change', hitungUmur);
          }
        });
    
        hitungUmur();
      });
    </script>
        
    <script>
      function updateTanggalLahir() {
        const tgl = document.getElementById('tanggal').value.padStart(2, '0');
        const bln = document.getElementById('bulan').value.padStart(2, '0');
        const thn = document.getElementById('tahun').value;
    
        if (tgl && bln && thn) {
          const tanggalLahirFormatted = `${tgl}-${bln}-${thn}`;
          document.getElementById('tanggal_lahir').value = tanggalLahirFormatted;
        } else {
          document.getElementById('tanggal_lahir').value = '';
        }
      }
    
      document.addEventListener('DOMContentLoaded', function () {
        ['tanggal', 'bulan', 'tahun'].forEach(function (id) {
          const el = document.getElementById(id);
          if (el) {
            el.addEventListener('change', updateTanggalLahir);
          }
        });
    
        updateTanggalLahir(); // Jalankan saat halaman pertama dimuat
      });
</script>

@stop