
<!-- Page Header End -->
<div class="main-page " id="main-page">		
  		<?php echo $content ;?>
</div>



