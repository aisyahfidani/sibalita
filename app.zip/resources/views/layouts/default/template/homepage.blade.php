
<section id="intro" class="">

  <div class="intro-content">
    <div>
      <h3> Complete Framework and Evironment for Web App </h3>
       <h5> Create from simple  to complex web and application  </h5> 
      <h2>Sximo Builder 7  <span></span> </h2>  
      <h6>Based on Popular various framework</h6>
      <p>Quick prototyping your application within a minute(s)</p>
    </div>
   
  </div>
</section>
<!-- #intro -->

<section class="block-section bg-grey">
  <div class="container">
    <h3> FEATURES AND BENEFITS </h3>
    <p> powerful automation tool that can generate a full set of PHP quickly from MySQL. <br />
You can instantly create web sites that allow users to view, edit, search, add and delete records on the web </p>
  </div>
</section>


<section  class="block-section no-padding ">
  <div class="container">
    <div class="row gridder">
        <div class="col-6 col-md-4 box">
          <i class="mdi mdi-view-quilt"></i>
            <h4> Complete Framework </h4>
            <p> Re-useable admin template and layout</p>
        </div>
        <div class="col-6 col-md-4 box">
          <i class="mdi mdi-alarm-multiple"></i>
            <h4> Builder & Generator Inside  </h4>
            <p> Module generator and builed with complete cruds functionality </p>
        </div>
        <div class="col-6 col-md-4 box">
            <i class="mdi mdi-content-duplicate"></i>  
            <h4> Easy Costumizable </h4>
            <p> Easy to modify in all element script  </p>
        </div>
        <div class="col-6 col-md-4 box">
            <i class="mdi mdi-layers"></i> 
            <h4> Built-In Core Module </h4>
            <p> Users Management and authentication already installed </p>
        </div>
        <div class="col-6 col-md-4 box">
            <i class="mdi mdi-newspaper"></i>
            <h4> Pages , CMS & Articles   </h4>
            <p> Ready mage basic web publisher   </p>
        </div>
        <div class="col-6 col-md-4 box">
            <i class="mdi mdi-chemical-weapon"></i>
            <h4> Module Option </h4>
            <p> Native , Ajax , Datatables , Blank & Report    </p>

        </div>
        <div class="col-6 col-md-4 box">
            <i class="mdi mdi-image"></i>
            <h4> Assets Management </h4>
            <p>  Manage assets such images and file directly from application    </p>
        </div>
        <div class="col-6 col-md-4 box">
            <i class="mdi mdi-tune"></i>
            <h4> Live Code Editor  </h4>
            <p>  Edit and modify all source code via application directly    </p>
        </div>
        <div class="col-6 col-md-4 box">
            <i class="mdi mdi-widgets"></i>
            <h4> Repositories </h4>
            <p>  Find andy suitable pre-made module , template or premium module & Plugins    </p>
        </div>
  </div>
</section>
