@extends('layouts.app')

@section('content')
{{--*/ usort($tableGrid, "SiteHelpers::_sort") /*--}}
<div class="page-titles">
  <h2> {{ $pageTitle }}</h2>
</div>
<div  class="card">
	<div class="card-body">
		<div class="toolbar-nav">
			<div class="row">
				<div class="col-md-4 ">
			        <div class="input-group">
			     
			         <input type="text" class="form-control form-control-sm onsearch" data-target="{{ url($pageModule) }}" aria-label="..." placeholder=" Type And Hit Enter ">
			        </div>
		        </div> 
        		<div class="col-md-8 text-right"> 	
        			<div class="btn-group">
        				@if($access['is_add'] ==1)
        				<a href="{{ url('core/users/create?return='.$return) }}" class="btn  btn-sm btn-info"  
        					title="{{ __('core.btn_create') }}"> Tambah </a>
        				@endif 
        				<div class="btn-group">
        					<button type="button" class="btn  btn-sm btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Aksi lainnya </button>
        			        <ul class="dropdown-menu">
        			         @if($access['is_remove'] ==1)
        						 <li class="nav-item"><a href="javascript://ajax"  onclick="SximoDelete();" class="nav-link tips" title="{{ __('core.btn_remove') }}">
        						Hapus </a></li>
        					@endif 
        			          
        			        </ul>
        			    </div>   
        			    
        			</div>	
        		</div>
			</div>
		<div >

	


		 {!! Form::open(array('url'=>'posyandulist/delete/', 'class'=>'form-horizontal' ,'id' =>'SximoTable' )) !!}
		 <div class="table-responsive" style="min-height:300px;">
	    <table class="table table-hover table-striped  ">
	        <thead>
				<tr>
					<th class="number"> No </th>			
					@foreach ($tableGrid as $t)
						@if($t['view'] =='1')
							<th>{{ $t['label'] }}</th>
						@endif
					@endforeach
				  </tr>
	        </thead>

	        <tbody>
							
	            @foreach ($rowData as $row)
	                <tr>
						<td width="30"> {{ ++$i }} </td>	
					@foreach ($tableGrid as $field)
						 @if($field['view'] =='1')
						 	<?php $limited = isset($field['limited']) ? $field['limited'] :''; ?>
						 	@if(SiteHelpers::filterColumn($limited ))
							 <td>					 
							 	{!! SiteHelpers::formatRows($row->{$field['field']},$field ,$row ) !!}						 
							 </td>
							@endif	
						 @endif					 
					 @endforeach				 
					
	                </tr>
					
	            @endforeach
	              
	        </tbody>
	      
	    </table>
		<input type="hidden" name="md" value="" />
		</div>
		{!! Form::close() !!}
		
		
		@include('footer')
	</div>  
</div>
@stop