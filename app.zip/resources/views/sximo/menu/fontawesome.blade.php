<div class="white-box">
<div class="icon-list-demo row">
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-address-book"></i> fas fa-address-book</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-address-card"></i> fas fa-address-card</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-adjust"></i> fas fa-adjust</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-align-center"></i> fas fa-align-center</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-align-justify"></i> fas fa-align-justify</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-align-left"></i> fas fa-align-left</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-align-right"></i> fas fa-align-right</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-allergies"></i> fas fa-allergies</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-ambulance"></i> fas fa-ambulance</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-american-sign-language-interpreting"></i> fas fa-american-sign-language-interpreting</div>
    <div class=" col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-anchor"></i> fas fa-anchor</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-angle-double-down"></i> fas fa-angle-double-down
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-angle-double-left"></i> fas fa-angle-double-left
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-angle-double-right"></i> fas fa-angle-double-right
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-angle-double-up"></i> fas fa-angle-double-up
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-angle-down"></i> fas fa-angle-down</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-angle-left"></i> fas fa-angle-left</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-angle-right"></i> fas fa-angle-right</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-angle-up"></i> fas fa-angle-up</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-archive"></i> fas fa-archive</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-arrow-alt-circle-down"></i> fas fa-arrow-alt-circle-down
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-arrow-alt-circle-left"></i> fas fa-arrow-alt-circle-left</div>
    <div class=" col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-arrow-alt-circle-right"></i> fas fa-arrow-alt-circle-right</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-arrow-alt-circle-up"></i> fas fa-arrow-alt-circle-up</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-arrow-circle-down"></i> fas fa-arrow-circle-down
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-arrow-circle-left"></i> fas fa-arrow-circle-left
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-arrow-circle-right"></i> fas fa-arrow-circle-right
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-arrow-circle-up"></i> fas fa-arrow-circle-up
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-arrow-down"></i> fas fa-arrow-down</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-arrow-left"></i> fas fa-arrow-left</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-arrow-right"></i> fas fa-arrow-right</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-arrow-up"></i> fas fa-arrow-up</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-arrows-alt"></i> fas fa-arrows-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-arrows-alt-h"></i> fas fa-arrows-alt-h</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-arrows-alt-v"></i> fas fa-arrows-alt-v</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-assistive-listening-systems"></i> fas fa-assistive-listening-systems</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-asterisk"></i> fas fa-asterisk</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-at"></i> fas fa-at</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-audio-description"></i> fas fa-audio-tion
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-backward"></i> fas fa-backward</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-balance-scale"></i> fas fa-balance-scale</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-ban"></i> fas fa-ban</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-band-aid"></i> fas fa-band-aid</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-barcode"></i> fas fa-barcode</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-bars"></i> fas fa-bars</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-baseball-ball"></i> fas fa-baseball-ball</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-basketball-ball"></i> fas fa-basketba
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-bath"></i> fas fa-bath</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-battery-empty"></i> fas fa-battery-empty</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-battery-full"></i> fas fa-battery-full</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-battery-half"></i> fas fa-battery-half</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-battery-quarter"></i> fas fa-battery-quarter
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon "><i class="fas fa-battery-three-quarters"></i> fas fa-battery-three-quarters
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-bed"></i> fas fa-bed</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-beer"></i> fas fa-beer</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-bell"></i> fas fa-bell</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-bell-slash"></i> fas fa-bell-slash</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-bicycle"></i> fas fa-bicycle</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-binoculars"></i> fas fa-binoculars</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-birthday-cake"></i> fas fa-birthday-cake</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-blind"></i> fas fa-blind</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-bold"></i> fas fa-bold</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-bolt"></i> fas fa-bolt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-bomb"></i> fas fa-bomb</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-book"></i> fas fa-book</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-bookmark"></i> fas fa-bookmark</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-bowling-ball"></i> fas fa-bowling-ball</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-box"></i> fas fa-box</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-box-open"></i> fas fa-box-open</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-boxes"></i> fas fa-boxes</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-braille"></i> fas fa-braille</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-briefcase"></i> fas fa-briefcase</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-briefcase-medical"></i> fas fa-briefcical
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-bug"></i> fas fa-bug</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-building"></i> fas fa-building</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-bullhorn"></i> fas fa-bullhorn</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-bullseye"></i> fas fa-bullseye</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-burn"></i> fas fa-burn</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-bus"></i> fas fa-bus</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-calculator"></i> fas fa-calculator</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-calendar"></i> fas fa-calendar</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-calendar-alt"></i> fas fa-calendar-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-calendar-check"></i> fas fa-calendar-check</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-calendar-minus"></i> fas fa-calendar-minus</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-calendar-plus"></i> fas fa-calendar-plus</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-calendar-times"></i> fas fa-calendar-times</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-camera"></i> fas fa-camera</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-camera-retro"></i> fas fa-camera-retro</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-capsules"></i> fas fa-capsules</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-car"></i> fas fa-car</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-caret-down"></i> fas fa-caret-down</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-caret-left"></i> fas fa-caret-left</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-caret-right"></i> fas fa-caret-right</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-caret-square-down"></i> fas fa-caret-down
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-caret-square-left"></i> fas fa-caret-left
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-caret-square-right"></i> fas fa-caret-right
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-caret-square-up"></i> fas fa-caret-sq
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-caret-up"></i> fas fa-caret-up</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-cart-arrow-down"></i> fas fa-cart-arr
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-cart-plus"></i> fas fa-cart-plus</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-certificate"></i> fas fa-certificate</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chart-area"></i> fas fa-chart-area</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chart-bar"></i> fas fa-chart-bar</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chart-line"></i> fas fa-chart-line</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chart-pie"></i> fas fa-chart-pie</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-check"></i> fas fa-check</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-check-circle"></i> fas fa-check-circle</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-check-square"></i> fas fa-check-square</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chess"></i> fas fa-chess</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chess-bishop"></i> fas fa-chess-bishop</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chess-board"></i> fas fa-chess-board</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chess-king"></i> fas fa-chess-king</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chess-knight"></i> fas fa-chess-knight</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chess-pawn"></i> fas fa-chess-pawn</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chess-queen"></i> fas fa-chess-queen</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chess-rook"></i> fas fa-chess-rook</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chevron-circle-down"></i> fas fa-chevron-circle-down</div>
    <div class=" col-sm-6 col-md-4 col-lg-3 f-icon "><i class="fas fa-chevron-circle-left"></i> fas fa-chevron-circle-left</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chevron-circle-right"></i> fas fa-chevron-circle-right</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chevron-circle-up"></i> fas fa-chevroe-up
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chevron-down"></i> fas fa-chevron-down</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chevron-left"></i> fas fa-chevron-left</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chevron-right"></i> fas fa-chevron-right</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-chevron-up"></i> fas fa-chevron-up</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-child"></i> fas fa-child</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-circle"></i> fas fa-circle</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-circle-notch"></i> fas fa-circle-notch</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-clipboard"></i> fas fa-clipboard</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-clipboard-check"></i> fas fa-clipboard-check
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-clipboard-list"></i> fas fa-clipboard-list</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-clock"></i> fas fa-clock</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-clone"></i> fas fa-clone</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-closed-captioning"></i> fas fa-closedning
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-cloud"></i> fas fa-cloud</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-cloud-download-alt"></i> fas fa-cloudad-alt
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-cloud-upload-alt"></i> fas fa-cloud-alt
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-code"></i> fas fa-code</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-code-branch"></i> fas fa-code-branch</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-coffee"></i> fas fa-coffee</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-cog"></i> fas fa-cog</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-cogs"></i> fas fa-cogs</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-columns"></i> fas fa-columns</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-comment"></i> fas fa-comment</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-comment-alt"></i> fas fa-comment-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-comment-dots"></i> fas fa-comment-dots</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-comment-slash"></i> fas fa-comment-slash</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-comments"></i> fas fa-comments</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-compass"></i> fas fa-compass</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-compress"></i> fas fa-compress</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-copy"></i> fas fa-copy</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-copyright"></i> fas fa-copyright</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-couch"></i> fas fa-couch</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-credit-card"></i> fas fa-credit-card</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-crop"></i> fas fa-crop</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-crosshairs"></i> fas fa-crosshairs</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-cube"></i> fas fa-cube</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-cubes"></i> fas fa-cubes</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-cut"></i> fas fa-cut</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-database"></i> fas fa-database</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-deaf"></i> fas fa-deaf</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-desktop"></i> fas fa-desktop</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-diagnoses"></i> fas fa-diagnoses</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-dna"></i> fas fa-dna</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-dollar-sign"></i> fas fa-dollar-sign</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-dolly"></i> fas fa-dolly</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-dolly-flatbed"></i> fas fa-dolly-flatbed</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-donate"></i> fas fa-donate</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-dot-circle"></i> fas fa-dot-circle</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-dove"></i> fas fa-dove</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-download"></i> fas fa-download</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-edit"></i> fas fa-edit</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-eject"></i> fas fa-eject</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-ellipsis-h"></i> fas fa-ellipsis-h</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-ellipsis-v"></i> fas fa-ellipsis-v</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-envelope"></i> fas fa-envelope</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-envelope-open"></i> fas fa-envelope-open</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-envelope-square"></i> fas fa-envelope-square
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-eraser"></i> fas fa-eraser</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-euro-sign"></i> fas fa-euro-sign</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-exchange-alt"></i> fas fa-exchange-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-exclamation"></i> fas fa-exclamation</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-exclamation-circle"></i> fas fa-exclamation-circle
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-exclamation-triangle"></i> fas fa-exclamation-triangle</div>
    <div class=" col-sm-6 col-md-4 col-lg-3 f-icon "><i class="fas fa-expand"></i> fas fa-expand</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon "><i class="fas fa-expand-arrows-alt"></i> fas fa-expand-alt
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon "><i class="fas fa-external-link-alt"></i> fas fa-external-link-alt
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon "><i class="fas fa-external-link-square-alt"></i> fas fa-external-link-square-alt
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-eye"></i> fas fa-eye</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-eye-dropper"></i> fas fa-eye-dropper</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-eye-slash"></i> fas fa-eye-slash</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-fast-backward"></i> fas fa-fast-backward</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-fast-forward"></i> fas fa-fast-forward</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-fax"></i> fas fa-fax</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-female"></i> fas fa-female</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-fighter-jet"></i> fas fa-fighter-jet</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-file"></i> fas fa-file</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-file-alt"></i> fas fa-file-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-file-archive"></i> fas fa-file-archive</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-file-audio"></i> fas fa-file-audio</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-file-code"></i> fas fa-file-code</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-file-excel"></i> fas fa-file-excel</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-file-image"></i> fas fa-file-image</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-file-medical"></i> fas fa-file-medical</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-file-medical-alt"></i> fas fa-file-medical-alt
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-file-pdf"></i> fas fa-file-pdf</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-file-powerpoint"></i> fas fa-file-pow
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-file-video"></i> fas fa-file-video</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-file-word"></i> fas fa-file-word</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-film"></i> fas fa-film</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-filter"></i> fas fa-filter</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-fire"></i> fas fa-fire</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-fire-extinguisher"></i> fas fa-fire-extinguisher
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-first-aid"></i> fas fa-first-aid</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-flag"></i> fas fa-flag</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-flag-checkered"></i> fas fa-flag-checkered</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-flask"></i> fas fa-flask</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-folder"></i> fas fa-folder</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-folder-open"></i> fas fa-folder-open</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-font"></i> fas fa-font</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-football-ball"></i> fas fa-football-ball</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-forward"></i> fas fa-forward</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-frown"></i> fas fa-frown</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-futbol"></i> fas fa-futbol</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-gamepad"></i> fas fa-gamepad</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-gavel"></i> fas fa-gavel</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-gem"></i> fas fa-gem</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-genderless"></i> fas fa-genderless</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-gift"></i> fas fa-gift</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-glass-martini"></i> fas fa-glass-martini</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-globe"></i> fas fa-globe</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-golf-ball"></i> fas fa-golf-ball</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-graduation-cap"></i> fas fa-graduation-cap</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-h-square"></i> fas fa-h-square</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hand-holding"></i> fas fa-hand-holding</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hand-holding-heart"></i> fas fa-hand-holding-heart
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hand-holding-usd"></i> fas fa-hand-holding-usd
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hand-lizard"></i> fas fa-hand-lizard</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hand-paper"></i> fas fa-hand-paper</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hand-peace"></i> fas fa-hand-peace</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hand-point-down"></i> fas fa-hand-point-down
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hand-point-left"></i> fas fa-hand-point-left
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hand-point-right"></i> fas fa-hand-point-right
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hand-point-up"></i> fas fa-hand-point-up</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hand-pointer"></i> fas fa-hand-pointer</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hand-rock"></i> fas fa-hand-rock</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hand-scissors"></i> fas fa-hand-scissors</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hand-spock"></i> fas fa-hand-spock</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hands"></i> fas fa-hands</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hands-helping"></i> fas fa-hands-helping</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-handshake"></i> fas fa-handshake</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hashtag"></i> fas fa-hashtag</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hdd"></i> fas fa-hdd</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-heading"></i> fas fa-heading</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-headphones"></i> fas fa-headphones</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-heart"></i> fas fa-heart</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-heartbeat"></i> fas fa-heartbeat</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-history"></i> fas fa-history </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hockey-puck"></i> fas fa-hockey-puck</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-home"></i> fas fa-home</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hospital"></i> fas fa-hospital</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hospital-alt"></i> fas fa-hospital-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hospital-symbol"></i> fas fa-hospital
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hourglass"></i> fas fa-hourglass</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hourglass-end"></i> fas fa-hourglass-end</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hourglass-half"></i> fas fa-hourglass-half</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-hourglass-start"></i> fas fa-hourglass-start
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-i-cursor"></i> fas fa-i-cursor</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-id-badge"></i> fas fa-id-badge</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-id-card"></i> fas fa-id-card</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-id-card-alt"></i> fas fa-id-card-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-image"></i> fas fa-image</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-images"></i> fas fa-images</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-inbox"></i> fas fa-inbox</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-indent"></i> fas fa-indent</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-industry"></i> fas fa-industry</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-info"></i> fas fa-info</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-info-circle"></i> fas fa-info-circle</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-italic"></i> fas fa-italic</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-key"></i> fas fa-key</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-keyboard"></i> fas fa-keyboard</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-language"></i> fas fa-language</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-laptop"></i> fas fa-laptop</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-leaf"></i> fas fa-leaf</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-lemon"></i> fas fa-lemon</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-level-down-alt"></i> fas fa-level-down-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-level-up-alt"></i> fas fa-level-up-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-life-ring"></i> fas fa-life-ring</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-lightbulb"></i> fas fa-lightbulb</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-link"></i> fas fa-link</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-lira-sign"></i> fas fa-lira-sign</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-list"></i> fas fa-list</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-list-alt"></i> fas fa-list-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-list-ol"></i> fas fa-list-ol</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-list-ul"></i> fas fa-list-ul</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-location-arrow"></i> fas fa-location-arrow</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-lock"></i> fas fa-lock</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-lock-open"></i> fas fa-lock-open</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-long-arrow-alt-down"></i> fas fa-long-arrow-alt-down</div>
    <div class=" col-sm-6 col-md-4 col-lg-3 f-icon "><i class="fas fa-long-arrow-alt-left"></i> fas fa-long-arrow-alt-left</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-long-arrow-alt-right"></i> fas fa-long-arrow-alt-right</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-long-arrow-alt-up"></i> fas fa-long-arrow-alt-up
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-low-vision"></i> fas fa-low-vision</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-magic"></i> fas fa-magic</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-magnet"></i> fas fa-magnet</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-male"></i> fas fa-male</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-map"></i> fas fa-map</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-map-marker"></i> fas fa-map-marker</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-map-marker-alt"></i> fas fa-map-marker-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-map-pin"></i> fas fa-map-pin</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-map-signs"></i> fas fa-map-signs</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-mars"></i> fas fa-mars</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-mars-double"></i> fas fa-mars-double</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-mars-stroke"></i> fas fa-mars-stroke</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-mars-stroke-h"></i> fas fa-mars-stroke-h</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-mars-stroke-v"></i> fas fa-mars-stroke-v</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-medkit"></i> fas fa-medkit</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-meh"></i> fas fa-meh</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-mercury"></i> fas fa-mercury</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-microchip"></i> fas fa-microchip</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-microphone"></i> fas fa-microphone</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-microphone-slash"></i> fas fa-microphone-slash
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-minus"></i> fas fa-minus</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-minus-circle"></i> fas fa-minus-circle</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-minus-square"></i> fas fa-minus-square</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-mobile"></i> fas fa-mobile</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-mobile-alt"></i> fas fa-mobile-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-money-bill-alt"></i> fas money-bill-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-moon"></i> fas fa-moon</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-motorcycle"></i> fas fa-motorcycle</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-mouse-pointer"></i> fas fa-mouse-pointer</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-music"></i> fas fa-music</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-neuter"></i> fas fa-neuter</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-newspaper"></i> fas fa-newspaper</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-notes-medical"></i> fas fa-notes-medical</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-object-group"></i> fas fa-object-group</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-object-ungroup"></i> fas fa-object-ungroup</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-outdent"></i> fas fa-outdent</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-paint-brush"></i> fas fa-paint-brush</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-pallet"></i> fas fa-pallet</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-paper-plane"></i> fas fa-paper-plane</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-paperclip"></i> fas fa-paperclip</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-parachute-box"></i> fas fa-parachute-box</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-paragraph"></i> fas fa-paragraph</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-paste"></i> fas fa-paste</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-pause"></i> fas fa-pause</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-pause-circle"></i> fas pause-circle</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-paw"></i> fas fa-fa-paw</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-pen-square"></i> fas fa-pen-square</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-pencil-alt"></i> fas fa-pencil-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-people-carry"></i> fas fa-people-carry</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-percent"></i> fas fa-percent</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-phone"></i> fas fa-phone</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-phone-slash"></i> fas fa-phone-slash</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-phone-square"></i> fas fa-phone-square</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-phone-volume"></i> fas fa-phone-volume</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-piggy-bank"></i> fas fa-piggy-bank</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-pills"></i> fas fa-pills</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-plane"></i> fas fa-plane</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-play"></i> fas fa-play</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-play-circle"></i> fas fa-play-circle</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-plug"></i> fas fa-plug</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-plus"></i> fas fa-plus</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-plus-circle"></i> fas fa-plus-circle</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-plus-square"></i> fas fa-plus-square</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-podcast"></i> fas fa-podcast</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-poo"></i> fas fa-poo</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-pound-sign"></i> fas fa-pound-sign</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-power-off"></i> fas fa-power-off</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-prescription-bottle"></i> fas fa-prescription-bottle</div>
    <div class=" col-sm-6 col-md-4 col-lg-3 f-icon "><i class="fas fa-prescription-bottle-alt"></i> fas fa-prescription-bottle-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-print"></i> fas fa-print</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-procedures"></i> fas fa-procedures</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-puzzle-piece"></i> fas fa-puzzle-piece</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-qrcode"></i> fas fa-qrcode</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-question"></i> fas fa-question</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-question-circle"></i> fas fa-question
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-quidditch"></i> fas fa-quidditch</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-quote-left"></i> fas fa-quote-left</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-quote-right"></i> fas fa-quote-right</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-random"></i> fas fa-random</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-recycle"></i> fas fa-recycle</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-redo"></i> fas fa-redo</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-redo-alt"></i> fas fa-redo-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-registered"></i> fas fa-registered</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-reply"></i> fas fa-reply</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-reply-all"></i> fas fa-reply-all</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-retweet"></i> fas fa-retweet</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-ribbon"></i> fas fa-ribbon</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-road"></i> fas fa-road</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-rocket"></i> fas fa-rocket</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-rss"></i> fas fa-rss</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-rss-square"></i> fas fa-rss-square</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-ruble-sign"></i> fas fa-ruble-sign</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-rupee-sign"></i> fas fa-rupee-sign</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-save"></i> fas fa-save</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-search"></i> fas fa-search</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-search-minus"></i> fas fa-search-minus</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-search-plus"></i> fas fa-search-plus</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-seedling"></i> fas fa-seedling</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-server"></i> fas fa-server</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-share"></i> fas fa-share</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-share-alt"></i> fas fa-share-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-share-alt-square"></i> fas fa-share-alt-square
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-share-square"></i> fas fa-share-square</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-shekel-sign"></i> fas fa-shekel-sign</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-shield-alt"></i> fas fa-shield-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-ship"></i> fas fa-ship</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-shipping-fast"></i> fas fa-shipping-fast</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-shopping-bag"></i> fas fa-shopping-bag</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-shopping-basket"></i> fas fa-shopping-basket
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-shopping-cart"></i> fas fa-shopping-cart</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-shower"></i> fas fa-shower</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sign"></i> fas fa-sign</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sign-in-alt"></i> fas fa-sign-in-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sign-language"></i> fas fa-sign-language</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sign-out-alt"></i> fas fa-sign-out-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-signal"></i> fas fa-signal</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sitemap"></i> fas fa-sitemap</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sliders-h"></i> fas fa-sliders-h</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-smile"></i> fas fa-smile</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-smoking"></i> fas fa-smoking</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-snowflake"></i> fas fa-snowflake</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sort"></i> fas fa-sort</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sort-alpha-down"></i> fas fa-alpha-down
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sort-alpha-up"></i> fas fa-sort-alpha-up</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sort-amount-down"></i> fas fa-sort-amount-down
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sort-amount-up"></i> fas fa-sort-amount-up</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sort-down"></i> fas fa-sort-down</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sort-numeric-down"></i> fas fa-sort-numeric-down
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sort-numeric-up"></i> fas fa-sort-numeric-up
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sort-up"></i> fas fa-sort-up</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-space-shuttle"></i> fas fa-space-shuttle</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-spinner"></i> fas fa-spinner</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-square"></i> fas fa-square</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-square-full"></i> fas fa-square-full</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-star"></i> fas fa-star</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-star-half"></i> fas fa-star-half</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-step-backward"></i> fas fa-step-backward</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-step-forward"></i> fas fa-step-forward</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-stethoscope"></i> fas fa-stethoscope</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sticky-note"></i> fas fa-sticky-note</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-stop"></i> fas fa-stop</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-stop-circle"></i> fas fa-stop-circle</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-stopwatch"></i> fas fa-stopwatch</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-street-view"></i> fas fa-street-view</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-strikethrough"></i> fas fa-strikethrough</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-subscript"></i> fas fa-subscript</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-subway"></i> fas fa-subway</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-suitcase"></i> fas fa-suitcase</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sun"></i> fas fa-sun</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-superscript"></i> fas fa-superscript</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sync"></i> fas fa-sync</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-sync-alt"></i> fas fa-sync-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-syringe"></i> fas fa-syringe</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-table"></i> fas fa-table</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-table-tennis"></i> fas fa-table-tennis</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-tablet"></i> fas fa-tablet</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-tablet-alt"></i> fas fa-tablet-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-tablets"></i> fas fa-tablets</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-tachometer-alt"></i> fas fa-tachometer-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-tag"></i> fas fa-tag</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-tags"></i> fas fa-tags</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-tape"></i> fas fa-tape</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-tasks"></i> fas fa-tasks</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-taxi"></i> fas fa-taxi</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-terminal"></i> fas fa-terminal</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-text-height"></i> fas fa-text-height</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-text-width"></i> fas fa-text-width</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-th"></i> fas fa-th</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-th-large"></i> fas fa-th-large</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-th-list"></i> fas fa-th-list</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-thermometer"></i> fas fa-thermometer</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-thermometer-empty"></i> fas fa-thermometer-empty
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-thermometer-full"></i> fas fa-thermometer-full
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-thermometer-half"></i> fas fa-thermometer-half
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-thermometer-quarter"></i> fas fa-thermometer-quarter</div>
    <div class=" col-sm-6 col-md-4 col-lg-3 f-icon "><i class="fas fa-thermometer-three-quarters"></i> fas fa-thermometer-three-quarters</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-thumbs-down"></i> fas fa-thumbs-down</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-thumbs-up"></i> fas fa-thumbs-up</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-thumbtack"></i> fas fa-thumbtack</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-ticket-alt"></i> fas fa-ticket-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-times"></i> fas fa-times</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-times-circle"></i> fas fa-times-circle</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-tint"></i> fas fa-tint</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-toggle-off"></i> fas fa-toggle-off</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-toggle-on"></i> fas fa-toggle-on</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-trademark"></i> fas fa-trademark</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-train"></i> fas fa-train</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-transgender"></i> fas fa-transgender</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-transgender-alt"></i> fas fa-transgen
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-trash"></i> fas fa-trash</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-trash-alt"></i> fas fa-trash-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-tree"></i> fas fa-tree</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-trophy"></i> fas fa-trophy</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-truck"></i> fas fa-truck</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-truck-loading"></i> fas fa-truck-loading</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-truck-moving"></i> fas fa-truck-moving</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-tty"></i> fas fa-tty</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-tv"></i> fas fa-tv</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-umbrella"></i> fas fa-umbrella</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-underline"></i> fas fa-underline</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-undo"></i> fas fa-undo</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-undo-alt"></i> fas fa-undo-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-universal-access"></i> fas fa-universal-access
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-university"></i> fas fa-university</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-unlink"></i> fas fa-unlink</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-unlock"></i> fas fa-unlock</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-unlock-alt"></i> fas fa-unlock-alt</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-upload"></i> fas fa-upload</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-user"></i> fas fa-user</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-user-circle"></i> fas fa-user-circle</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-user-md"></i> fas fa-user-md</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-user-plus"></i> fas fa-user-plus</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-user-secret"></i> fas fa-user-secret</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-user-times"></i> fas fa-user-times</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-users"></i> fas fa-users</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-utensil-spoon"></i> fas fa-utensil-spoon</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-utensils"></i> fas fa-utensils</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-venus"></i> fas fa-venus</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-venus-double"></i> fas fa-venus-double</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-venus-mars"></i> fas fa-venus-mars</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-vial"></i> fas fa-vial</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-vials"></i> fas fa-vials</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-video"></i> fas fa-video</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-video-slash"></i> fas fa-video-slash</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-volleyball-ball"></i> fas fa-volleyba
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-volume-down"></i> fas fa-volume-down</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-volume-off"></i> fas fa-volume-off</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-volume-up"></i> fas fa-volume-up</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-warehouse"></i> fas fa-warehouse</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-weight"></i> fas fa-weight</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-wheelchair"></i> fas fa-wheelchair</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-wifi"></i> fas fa-wifi</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-window-close"></i> fas fa-window-close</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-window-maximize"></i> fas fa-window-maximize
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-window-minimize"></i> fas fa-window-minimize
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-window-restore"></i> fas fa-window-restore</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-wine-glass"></i> fas fa-wine-glass</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-won-sign"></i> fas fa-won-sign</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-wrench"></i> fas fa-wrench</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-x-ray"></i> fas fa-x-ray</div>
    <div class="col-sm-6 col-md-4 col-lg-3 f-icon"><i class="fas fa-yen-sign"></i> fas fa-yen-sign</div>
</div>
</div>