<script>
$(document).ready(function() { 
	$('#sximo-modal .btn-form').hide()
	$('.modal-body .toolbar-nav').show()

})
</script>