<!-- AJax -->
<link href="<?php echo  asset('assets/plugins/ajax/ajaxSximo.css') ;?>" rel="stylesheet"> 
<script type="text/javascript" src="<?php echo  asset('assets/plugins/ajax/ajaxSximo.js') ;?>"></script>

<!-- End Ajax -->