<!-- Extension Datatables-->
<script type="text/javascript" src="<?php echo  asset('assets/plugins/datatable/media/js/jquery.dataTables.min.js') ?>"></script>
<link href="<?php echo  asset('assets/plugins/datatable/media/css/dataTables.bootstrap.css') ?>" rel="stylesheet">
<link href="<?php echo  asset('assets/plugins/datatable/extensions/Buttons/css/buttons.dataTables.min.css') ?>" rel="stylesheet">

<script type="text/javascript" src="<?php echo  asset('assets/plugins/datatable/sximo.datatables.js') ?>"></script>
<link href="<?php echo  asset('assets/plugins/datatable/sximo.datatables.css') ?>" rel="stylesheet">
<!-- End Extension Datatables-->