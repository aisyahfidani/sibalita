<h4> Basic Form Information </h4>
<ol>
	
	<li> <b>Form Name :</b> Name of your form </li>  
	<li> <b> Save Submited Form :</b> You can save into current database or send all submited value into spesific email </li>
	<li> <b> Table Name :  </b> If you prefer to save submited into database , please select database table </li>
	<li> <b> Email Address : </b> If you prefer to save/send submited to Email , please define email address </li>
	<li> <b> Redirect URL : </b> After form submited , redirect to spesific url . </li>
	<li> <b> Success Note : </b> Display note after form successed </li>
	<li> <b> Failed Note : </b> Display note if fail submit form</li>

</ol>

<h4> Usage / How To Use </h4>
<ol>
	<li> Create / open page CMS </li>
<li> Copy Shortcode : <b> !!FormHelpers|render|1!! </b> to page CMS </li>
</ol>