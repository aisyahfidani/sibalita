<?php  
   eval($code);
?>    