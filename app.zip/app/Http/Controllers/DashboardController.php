<?php namespace App\Http\Controllers;

use App\Http\Controllers;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Databalita;
use App\User;
use DB,Auth;

class DashboardController extends Controller {

	public function __construct()
	{
		parent::__construct();
		
        $this->data = array(
            'pageTitle' =>  $this->config['cnf_appname'],
            'pageNote'  =>  'Welcome to Dashboard',
            
        );			
	}

	public function index( Request $request )
	{
		$dataBalita = DB::table('data_balita')->count();
		$dataPosyandu = DB::table('posyandu')->count();
		$dataStunting = Databalita::select('kategori_balita', DB::raw('COUNT(*) as jumlah_balita'))
            ->whereIn('kategori_balita', ['Pendek', 'Sangat Pendek'])
            ->groupBy('kategori_balita')
            ->count();
// 		dd($dataStunting);
		$this->data['dataBalita'] 		= $dataBalita;
		$this->data['dataPosyandu'] 	= $dataPosyandu;
		$this->data['dataStunting'] 	= $dataStunting;
		return view('dashboard.index',$this->data);
	}	


	


}