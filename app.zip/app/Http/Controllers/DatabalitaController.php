<?php namespace App\Http\Controllers;

use Maatwebsite\Excel\Facades\Excel;
use App\Imports\BalitaImport;
use App\Models\Databalita;
use MyHelpers;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator as Paginator;
use Validator, Input, Redirect ; 
use DB,Auth;
use Carbon\Carbon;
use App\Charts\SampleChart;
use App\Providers\ChartsServiceProvider;


class DatabalitaController extends Controller {

	protected $layout = "layouts.main";
	protected $data = array();	
	public $module = 'databalita';
	static $per_page	= '25';

	public function __construct()
	{		
		parent::__construct();
		$this->model = new Databalita();	
		
		$this->info = $this->model->makeInfo( $this->module);	
		$this->data = array(
			'pageTitle'	=> 	$this->info['title'],
			'pageNote'	=>  $this->info['note'],
			'pageModule'=> 'databalita',
			'return'	=> self::returnUrl()
			
		);
		
	}

	public function index( Request $request )
	{
		// Make Sure users Logged 
		if(!\Auth::check()) 
			return redirect('user/login')->with('status', 'error')->with('message','You are not login');

		
		$this->grab( $request) ;
		if($this->access['is_view'] ==0) 
			return redirect('dashboard')->with('message', __('core.note_restric'))->with('status','error');				
		// Render into template
		
		return view( $this->module.'.index',$this->data);
	}	

	public function downloadTemplate()
	{
		$dataPosyandu = DB::table('tb_users')->where('group_id', '=', '3')->get();
		$dataDesa = DB::table('data_desa')->get();
		// dd($dataDesa);
		return view('databalita.templateBalita');
	}
	
	
	public function importDataBalita(Request $request)
    {
        // Validasi file upload
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv'
        ]);
    
        try {
            $file = $request->file('file');
            $array = Excel::toArray(new BalitaImport, $file);
    
            foreach ($array[0] as $k) {
                // Pastikan setiap data memiliki format lengkap
                if (!isset($k[4], $k[6])) {
                    return redirect()->back()->withErrors('Data pada file tidak lengkap.');
                }
    
                // Ambil referensi WHO berdasarkan umur dan jenis kelamin
                $referensi = DB::table('standar_who')
                    ->where('umur', $k[4])
                    ->first();
    
                if (!$referensi) {
                    return redirect()->back()->withErrors('Data referensi WHO untuk umur ' . $k[4] . ' tidak ditemukan.');
                }
    
                // Hitung z-score
                $sd = ($referensi->plus_1_sd - $referensi->median);
                if ($sd == 0) {
                    return redirect()->back()->withErrors('Kesalahan dalam data referensi WHO: SD tidak valid.');
                }
    
                $z_score = ($k[6] - $referensi->median) / $sd;
                
                // Fungsi Status Gizi BB/U

                if ($zscore < -3) {
                        return $bbu = "Berat badan sangat kurang (severely underweight)";
                    } elseif ($zscore >= -3 && $zscore < -2) {
                        return $bbu = "Berat badan kurang (underweight)";
                    } elseif ($zscore >= -2 && $zscore <= 1) {
                        return $bbu = "Berat badan normal";
                    } else {
                        return $bbu = "Risiko berat badan lebih";
                
                }
    
                // Tentukan status PB/U
                if ($zscore < -3) {
                    return $pbu = "Sangat pendek (severely stunted)";
                    } elseif ($zscore >= -3 && $zscore < -2) {
                        return $pbu = "Pendek (stunted)";
                    } elseif ($zscore >= -2 && $zscore <= 3) {
                        return $pbu = "Normal";
                    } else {
                        return $pbu = "Tinggi";
                }
                
                // Fungsi Status Gizi BB/PB atau BB/TB

                if ($zscore < -3) {
                        return $bbpb = "Gizi buruk (severely wasted)";
                    } elseif ($zscore >= -3 && $zscore < -2) {
                        return $bbpb = "Gizi kurang (wasted)";
                    } elseif ($zscore >= -2 && $zscore <= 1) {
                        return $bbpb = "Gizi baik (normal)";
                    } elseif ($zscore > 1 && $zscore <= 2) {
                        return $bbpb = "Berisiko gizi lebih";
                    } elseif ($zscore > 2 && $zscore <= 3) {
                        return $bbpb = "Gizi lebih (overweight)";
                    } else {
                        return $bbpb = "Obesitas (obese)";
                }
    
                // Simpan data
                // dd($k[3]);
                $tanggalLahir = Carbon::parse($k[3])->format('Y-m-d');
                $dataSave = new Databalita();
                $dataSave->nama_desa = $k[0] ?? null;
                $dataSave->nama_posyandu = $k[1] ?? null;
                $dataSave->nama_balita = $k[2] ?? null;
                $dataSave->tanggal_lahir = $tanggalLahir;
                $dataSave->umur_balita = $k[4];
                $dataSave->berat_balita = $k[5] ?? null;
                $dataSave->tinggi_badan_balita = $k[6];
                $dataSave->kategori_balita = $statusPBU;
                $dataSave->save();
            }
    
            return redirect('databalita')->with('message', __('core.note_success'))->with('status', 'success');
        } catch (\Exception $e) {
            return redirect()->back()->withErrors('Terjadi kesalahan: ' . $e->getMessage());
        }
    }

	function create( Request $request , $id =0 ) 
	{
		$this->hook( $request  );
		if($this->access['is_add'] ==0) 
			return redirect('dashboard')->with('message', __('core.note_restric'))->with('status','error');

		$this->data['row'] = $this->model->getColumnTable( $this->info['table']); 
		
		$this->data['id'] = '';
		return view($this->module.'.form',$this->data);
	}
	function edit( Request $request , $id ) 
	{
		$this->hook( $request , $id );
		if(!isset($this->data['row']))
			return redirect($this->module)->with('message','Record Not Found !')->with('status','error');
		if($this->access['is_edit'] ==0 )
			return redirect('dashboard')->with('message',__('core.note_restric'))->with('status','error');
		$this->data['row'] = (array) $this->data['row'];

		$chart = new SampleChart;
		$chart->labels(['One', 'Two', 'Three', 'Four']);
		$chart->dataset('My dataset', 'line', [1, 2, 3, 4]);
		$chart->dataset('My dataset 2', 'line', [4, 3, 2, 1]);
		$this->data['chart'] = $chart;
		$this->data['id'] = $id;
		return view($this->module.'.form',$this->data);
	}	
	function show( Request $request , $id ) 
	{
		/* Handle import , export and view */
		$task =$id ;
		switch( $task)
		{
			case 'search':
				return $this->getSearch();
				break;
			case 'lookup':
				return $this->getLookup($request );
				break;
			case 'comboselect':
				return $this->getComboselect( $request );
				break;
			case 'import':
				return $this->getImport( $request );
				break;
			case 'export':
				return $this->getExport( $request );
				break;
			default:
				$this->hook( $request , $id );
				if(!isset($this->data['row']))
					return redirect($this->module)->with('message','Record Not Found !')->with('status','error');

				if($this->access['is_detail'] ==0) 
					return redirect('dashboard')->with('message', __('core.note_restric'))->with('status','error');

				return view($this->module.'.view',$this->data);	
				break;		
		}
	}
	function store( Request $request  )
	{
	   // return dump($request->all());
	    
		$task = $request->input('action_task');
		switch ($task)
		{
			default:
				$rules = $this->validateForm();
				$validator = Validator::make($request->all(), $rules);
				if ($validator->passes()) 
				{
				    // return dump($request->all());
					$data = $this->validatePost( $request );
					$id = $this->model->insertRow($data , $request->input( $this->info['key']));
				
				// Ambil referensi WHO berdasarkan umur dan jenis kelamin
                    // $referensi = DB::table('standar_who')
                    //     ->where('umur', $request->input('umur_balita'))
                    //     // ->where('jenis_kelamin', 'laki-laki')
                    //     ->first();
                    // // return dd($referensi);
                    // if (!$referensi) {
                    //     return 'Data referensi tidak ditemukan';
                    // }
                    
                    // $tanggal_lahir = sprintf('%04d-%02d-%02d', $request->tahun, $request->bulan, $request->tanggal);

            
                    $updateDataStunting = MyHelpers::statusPBU($request->input('umur_balita'), $request->input('tinggi_badan_balita'), $request->input('jenis_kelamin') ); //$umur, $tinggiBadan, $jenisKelamin
					DB::table('data_balita')->where('id', $id)->update(['kategori_balita' => $updateDataStunting]);
                          
					/* Insert logs */
					$this->model->logs($request , $id);
					if($request->has('apply'))
						return redirect( $this->module .'/'.$id.'/edit?'. $this->returnUrl() )->with('message',__('core.note_success'))->with('status','success');

					return redirect( $this->module .'?'. $this->returnUrl() )->with('message',__('core.note_success'))->with('status','success');
				} 
				else {
					if( $request->input(  $this->info['key'] ) =='') {
						$url = $this->module.'/create?'. $this->returnUrl();
					} else {
						$url = $this->module .'/'.$id.'/edit?'. $this->returnUrl();
					}
					return redirect( $url )
							->with('message',__('core.note_error'))->with('status','error')
							->withErrors($validator)->withInput();
								

				}
				break;
			case 'public':
				return $this->store_public( $request );
				break;

			case 'delete':
				$result = $this->destroy( $request );
				return redirect($this->module.'?'.$this->returnUrl())->with($result);
				break;

			case 'import':
				return $this->PostImport( $request );
				break;

			case 'copy':
				$result = $this->copy( $request );
				return redirect($this->module.'?'.$this->returnUrl())->with($result);
				break;		
		}	
	
	}	

	public function destroy( $request)
	{
		// Make Sure users Logged 
		if(!\Auth::check()) 
			return redirect('user/login')->with('status', 'error')->with('message','You are not login');

		$this->access = $this->model->validAccess($this->info['id'] , session('gid'));
		if($this->access['is_remove'] ==0) 
			return redirect('dashboard')
				->with('message', __('core.note_restric'))->with('status','error');
		// delete multipe rows 
		if(is_array($request->input('ids')))
		{
			$this->model->destroy($request->input('ids'));
			
			\SiteHelpers::auditTrail( $request , "ID : ".implode(",",$request->input('ids'))."  , Has Been Removed Successfull");
			// redirect
        	return ['message'=>__('core.note_success_delete'),'status'=>'success'];	
	
		} else {
			return ['message'=>__('No Item Deleted'),'status'=>'error'];				
		}

	}	
	
	public static function display(  )
	{
		$mode  = isset($_GET['view']) ? 'view' : 'default' ;
		$model  = new Databalita();
		$info = $model::makeInfo('databalita');
		$data = array(
			'pageTitle'	=> 	$info['title'],
			'pageNote'	=>  $info['note']			
		);	
		if($mode == 'view')
		{
			$id = $_GET['view'];
			$row = $model::getRow($id);
			if($row)
			{
				$data['row'] =  $row;
				$data['fields'] 		=  \SiteHelpers::fieldLang($info['config']['grid']);
				$data['id'] = $id;
				return view('databalita.public.view',$data);			
			}			
		} 
		else {

			$page = isset($_GET['page']) ? $_GET['page'] : 1;
			$params = array(
				'page'		=> $page ,
				'limit'		=>  (isset($_GET['rows']) ? filter_var($_GET['rows'],FILTER_VALIDATE_INT) : 10 ) ,
				'sort'		=> $info['key'] ,
				'order'		=> 'asc',
				'params'	=> '',
				'global'	=> 1 
			);

			$result = $model::getRows( $params );
			$data['tableGrid'] 	= $info['config']['grid'];
			$data['rowData'] 	= $result['rows'];	

			$page = $page >= 1 && filter_var($page, FILTER_VALIDATE_INT) !== false ? $page : 1;	
			$pagination = new Paginator($result['rows'], $result['total'], $params['limit']);	
			$pagination->setPath('');
			$data['i']			= ($page * $params['limit'])- $params['limit']; 
			$data['pagination'] = $pagination;
			return view('databalita.public.index',$data);	
		}

	}
	function store_public( $request)
	{
		
		$rules = $this->validateForm();
		$validator = Validator::make($request->all(), $rules);	
		if ($validator->passes()) {
			$data = $this->validatePost(  $request );		
			 $this->model->insertRow($data , $request->input('id'));
			return  Redirect::back()->with('message',__('core.note_success'))->with('status','success');
		} else {

			return  Redirect::back()->with('message',__('core.note_error'))->with('status','error')
			->withErrors($validator)->withInput();

		}	
	
	}
	
	function grafikBalita( $id)
	{
		$cekDataBalita = DB::table('data_balita')->where('id', '=', $id)->get();
		$listDataBalita = DB::table('data_balita')
						->where('nama_balita', '=', $cekDataBalita[0]->nama_balita)
						->where('nama_posyandu', '=', $cekDataBalita[0]->nama_posyandu)
						->where('nama_desa', '=', $cekDataBalita[0]->nama_desa)
						->orderBy('id', 'DESC')
						->get();
				// 		dd($listDataBalita);
		$cekDataUmurBalita = DB::table('data_balita')
						->where('nama_balita', '=', $cekDataBalita[0]->nama_balita)
						->where('nama_posyandu', '=', $cekDataBalita[0]->nama_posyandu)
						->where('nama_desa', '=', $cekDataBalita[0]->nama_desa)
						->pluck('umur_balita');
		$cekDataBeratBalita = DB::table('data_balita')
						->where('nama_balita', '=', $cekDataBalita[0]->nama_balita)
						->where('nama_posyandu', '=', $cekDataBalita[0]->nama_posyandu)
						->where('nama_desa', '=', $cekDataBalita[0]->nama_desa)
						->pluck('berat_balita');
		$cekDataTinggiBalita = DB::table('data_balita')
						->where('nama_balita', '=', $cekDataBalita[0]->nama_balita)
						->where('nama_posyandu', '=', $cekDataBalita[0]->nama_posyandu)
						->where('nama_desa', '=', $cekDataBalita[0]->nama_desa)
						->pluck('tinggi_badan_balita');
		
		// dd($cekDataTinggiBalita);

		$data['cekDataBalita'] 			= $cekDataBalita;
		$data['cekDataUmurBalita']		= $cekDataUmurBalita;
		$data['cekDataBeratBalita'] 	= $cekDataBeratBalita;
		$data['cekDataTinggiBalita'] 	= $cekDataTinggiBalita;

		return view('databalita.perkembanganBalita',$data);	
	}
}
