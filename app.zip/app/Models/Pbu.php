<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class pbu extends Sximo  {
	
	protected $table = 'tabel_pbu';
	protected $primaryKey = 'id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return "  SELECT tabel_pbu.* FROM tabel_pbu  ";
	}	

	public static function queryWhere(  ){
		
		return "  WHERE tabel_pbu.id IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
