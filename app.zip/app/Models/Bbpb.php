<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class bbpb extends Sximo  {
	
	protected $table = 'tabel_bbpb';
	protected $primaryKey = 'id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return "  SELECT tabel_bbpb.* FROM tabel_bbpb  ";
	}	

	public static function queryWhere(  ){
		
		return "  WHERE tabel_bbpb.id IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
