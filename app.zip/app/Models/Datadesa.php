<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class datadesa extends Sximo  {
	
	protected $table = 'data_desa';
	protected $primaryKey = 'id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return "  SELECT data_desa.* FROM data_desa  ";
	}	

	public static function queryWhere(  ){
		
		return "  WHERE data_desa.id IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
