<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use DB,Auth;

class databalita extends Sximo  {
	
	protected $table = 'data_balita';
	protected $primaryKey = 'id';
	// protected $fillable = ['nama_desa','nama_posyandu','nama_balita','tanggal_lahir','umur_balita','berat_balita','tinggi_badan_balita'];
	
	public function __construct() {
		parent::__construct();
		
	}


	public $timestamps = false;

	public static function querySelect(  ){
		
		return " SELECT data_balita.* FROM data_balita ";
	}	

	public static function queryWhere(  ){
		$idGroupUser = Auth::user()->group_id;
		if ($idGroupUser == '3') {
			return " WHERE data_balita.nama_posyandu = ".Auth::user()->id;
		}
		else{
			return " WHERE data_balita.id IS NOT NULL ";
		}
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
