<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class posyandulist extends Sximo  {
	
	protected $table = 'v_posyandu';
	protected $primaryKey = '';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return " SELECT v_posyandu.* FROM v_posyandu ";
	}	

	public static function queryWhere(  ){
		
		return " where group_id = 3 ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
