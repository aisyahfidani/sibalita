<?php

namespace App\Imports;

use App\Models\Databalita;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\Importable;

class BalitaImport implements ToCollection


{
    // use Importable;
    public function model(array $row)
    {
        // dd($row[5]);
        return new Databalita([
           
            'nama_desa'             => $row[0],
            'nama_posyandu'         => $row[1], 
            'nama_balita'           => $row[2],
            'tanggal_lahir'         => $row[3],
            'umur_balita'           => $row[4],
            'berat_balita'          => $row[5],
            'tinggi_badan_balita'   => $row[6],
        ]);
    }

    public function collection(Collection $rows)
    {

    }


}
