<?php 
/*

	This is general helpers for your applications 
	any library or helper should be write here

*/
class MyHelpers {

	public static function documentation( $id ) {
	//	return $id ;
		$param = explode('-',$id );
		$id 	= $param[0];
		$type 	= isset($param[1]) ? $param[1] : 'default';
		return  \App::call('App\\Http\\Controllers\DocsController@documentation',['id' => $id ,'type' => $type ]);
		return  $param;
	}
	public static function knowledgebase( $id ) {
		return  \App::call('App\\Http\\Controllers\DocsController@knowledgebase');
		return  $param;
	}

	static function cekPerkembangan ( $nama ){
		$dataBalita = DB::table('data_balita')->where('nama_balita', '=', $nama)->get();
		return $dataBalita;
	}
	
	static function umurBalita ( $umur ){
		if($umur != '') {
			return $umur.' Bulan';
// 			return round($umur/30,2).' Bulan';
		} else return $umur;
	}
	
	static function beratBalita ( $berat ){
		if($berat != '') {
			return $berat.' kg';
		}else return $berat;
	}
	
	static function tinggiBalita ( $tinggi ){
		if($tinggi != '') {
			return $tinggi.' cm';
		} else return $tinggi;
	}

	static function statusBB ( $umur, $beratBadan ){
	  if(($umur != NULL) || ($beratBadan != NULL)) 
		{
		  $standarBBU = [
                'median' => 10.0, // Median berat badan sesuai umur (contoh)
                'sd' => 1.5       // Standar deviasi
            ];
            
             $zScore = ($beratBadan - $standarBBU['median']) / $standarBBU['sd'];

            // Tentukan status berdasarkan Z-Score
            if ($zScore < -3) {
                return "Gizi Buruk";
            } elseif ($zScore >= -3 && $zScore < -2) {
                return "Gizi Kurang";
            } elseif ($zScore >= -2 && $zScore <= 2) {
                return "Gizi Baik";
            } else {
                return "Gizi Lebih";
            }
		}
		
		
	}
	
	static function statusBBPB($panjangBadan, $beratBadan  ) {
        $standarBBPB = [
            'median' => 9.5, // Median berat badan sesuai panjang badan (contoh)
            'sd' => 1.2
        ];
        
        $zScore = ($beratBadan - $standarBBPB['median']) / $standarBBPB['sd'];

        // Tentukan status berdasarkan Z-Score
        if ($zScore < -3) {
            return "Sangat Kurus";
        } elseif ($zScore >= -3 && $zScore < -2) {
            return "Kurus";
        } elseif ($zScore >= -2 && $zScore <= 2) {
            return "Normal";
        } else {
            return "Gemuk";
        }
        
    }
    
    
	static function statusPBU ($umur, $tinggiBadan, $jenisKelamin ){
	    
	    // Ambil referensi WHO berdasarkan umur dan jenis kelamin
        $referensi = DB::table('standar_who')
            ->where('umur', $umur)
            // ->where('jenis_kelamin', 'laki-laki')
            ->first();
        // return dd($referensi->umur);
        if (!$referensi) {
            return 'Data referensi tidak ditemukan';
        }

        // Hitung z-score
         $sd = ($referensi->plus_1_sd - $referensi->median); // SD dihitung dari median dan +1 SD
        // Hitung z-score
        $z_score = ($tinggiBadan - $referensi->median) / $sd;

        // Tentukan status PB/U
        if ($z_score < -3) {
            return "Sangat Pendek";
        } elseif ($z_score >= -3 && $z_score < -2) {
            return "Pendek";
        } elseif ($z_score >= -2 && $z_score <= 2) {
            return "Normal";
        } elseif ($z_score > 2) {
            return "Tinggi";
        }

       
        
	}
	
	static function statusPBUXXXXXX ($umur, $tinggiBadan, $jenisKelamin ){
	    
	    // Ambil referensi WHO berdasarkan umur dan jenis kelamin
        $referensi = DB::table('standar_who')
            ->where('umur', $umur)
            ->where('jenis_kelamin', 'laki-laki')
            ->first();
        // return dd($referensi->umur);
        if (!$referensi) {
            return 'Data referensi tidak ditemukan';
        }

        // Hitung z-score
         $sd = ($referensi[0]->plus_1_sd - $referensi[0]->median); // SD dihitung dari median dan +1 SD
        // Hitung z-score
        $z_score = ($tinggiBadan - $referensi[0]->median) / $sd;

        // Tentukan status PB/U
        if ($z_score < -3) {
            return "Sangat Pendek";
        } elseif ($z_score >= -3 && $z_score < -2) {
            return "Pendek";
        } elseif ($z_score >= -2 && $z_score <= 2) {
            return "Normal";
        } elseif ($z_score > 2) {
            return "Tinggi";
        }

       
        
	}
	
	// Contoh data standar WHO (World Health Organization)
        

	static function hitungJumlahPendek($dataBalita, $standarPBU) {
	    
	    $standarBBU = [
            'median' => 10.0, // Median berat badan sesuai umur (contoh)
            'sd' => 1.5       // Standar deviasi
        ];
        
        $standarBBPB = [
            'median' => 9.5, // Median berat badan sesuai panjang badan (contoh)
            'sd' => 1.2
        ];
        
        $standarPBU = [
            'median' => 80.0, // Median panjang badan sesuai umur (contoh)
            'sd' => 3.0
        ];
        
        
        $jumlahPendek = 0;
        $jumlahSangatPendek = 0;
    
        foreach ($dataBalita as $balita) {
            $zScore = ($balita['panjangBadan'] - $standarPBU['median']) / $standarPBU['sd'];
    
            if ($zScore < -3) {
                $jumlahSangatPendek++;
            } elseif ($zScore >= -3 && $zScore < -2) {
                $jumlahPendek++;
            }
        }
    
        return [
            'pendek' => $jumlahPendek,
            'sangatPendek' => $jumlahSangatPendek
        ];
    }
	
	static function statusBB_OLD ( $umur, $berat,$tinggi ){
		if(($umur != NULL) || ($berat != NULL) || ($tinggi != NULL)) 
		{
// 			$umurBulan = round($umur/30,2); (dalam hari)
			$umurBulan = $umur;
			// return dump($umurBulan);
			
				//  Usia 0 bulan atau baru lahir: 2,5—3,9 kilokgam (kg).
				if($umurBulan <= 1)
				{
					if(($berat <= 2))
					{
						$statusBB = 'Berat badan Berat badan sangat kurang';
					} elseif(($berat >= 2) && ($berat <= 2.5))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat >= 2.5) && ($berat <= 3.9))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}

				//  Usia 1 bulan: 3,4—5,1 kg.
				elseif(($umurBulan >= 1) && ($umurBulan <= 2))
				{
					if(($berat <= 2))
					{
						$statusBB = 'Berat badan Berat badan sangat kurang';
					} elseif(($berat >= 2.1) && ($berat <= 3.3))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat >= 3.4) && ($berat <= 5.1))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}

				//  Usia 2 bulan: 4,3—6,3 kg.
				elseif(($umurBulan >= 2) && ($umurBulan <= 3))
				{
					if(($berat <= 2.3))
					{
						$statusBB = 'Berat badan Berat badan sangat kurang';
					} elseif(($berat >= 2.4) && ($berat <= 4.2))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat >= 4.3) && ($berat <= 6.3))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}

				//  Usia 3 bulan: 5,0—7,2 kg.
				elseif(($umurBulan > 3) && ($umurBulan < 4))
				{
					if(($berat < 3.0))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 3.1) && ($berat <= 5))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 5.1) && ($berat < 7.2))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}
				//  Usia 4 bulan: 5,6—7,8 kg.
				elseif(($umurBulan > 4) && ($umurBulan < 5))
				{
					if(($berat < 3.6))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 3.7) && ($berat <= 5.5))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 5.6) && ($berat < 7.8))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}

				//  Usia 5 bulan: 6,0—8,4 kg.
				elseif(($umurBulan > 5) && ($umurBulan < 6))
				{
					if(($berat < 3.6))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 3.7) && ($berat <= 5.9))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 6) && ($berat < 8.4))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}	

				//  Usia 6 bulan: 6,4—8,8 kg.
				elseif(($umurBulan > 6) && ($umurBulan < 7))
				{
					if(($berat < 3.6))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 3.7) && ($berat <= 6.3))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 6.4) && ($berat < 8.8))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}

				//  Usia 7 bulan: 6,7—9,2 kg.
				elseif(($umurBulan > 7) && ($umurBulan < 8))
				{
					if(($berat < 4))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 4.1) && ($berat <= 6.6))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 6.7) && ($berat < 9.2))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Berebih';
					// menampilkan di table
					return $statusBB;
				}

				//  Usia 8 bulan: 6,9—9,6 kg.
				elseif(($umurBulan > 8) && ($umurBulan < 9))
				{
					if(($berat < 3.6))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 3.7) && ($berat <= 6.8))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 6.9) && ($berat < 9.6))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}	

				//  Usia 9 bulan: 7,1—9,9 kg.
				elseif(($umurBulan > 9) && ($umurBulan < 10))
				{
					if(($berat < 3.6))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 3.7) && ($berat <= 7.1))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 7.1) && ($berat < 9.9))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}

				//  Usia 10 bulan: 7,4—10,2 kg.
				elseif(($umurBulan > 10) && ($umurBulan < 11))
				{
					if(($berat < 4))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 4.1) && ($berat <= 7.3))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 7.4) && ($berat < 10.2))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}
				//  Usia 11 bulan: 7,6—10,5 kg.
				elseif(($umurBulan > 11) && ($umurBulan < 12))
				{
					if(($berat < 4.1))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 4.2) && ($berat <= 7.5))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 7.6) && ($berat < 10.5))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}

				// 1 tahun: 7,7–12 kg
				elseif(($umurBulan > 12 )&&( $umurBulan < 18))
				{
					if(($berat < 4.1))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 4.2) && ($berat <= 7.7))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 7.7) && ($berat < 12))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}

				//  Usia 13 bulan: 7,9—11,0 kg.

				// 1 tahun, 6 bulan: 8,8–13,7 kg
				elseif(($umurBulan > 18 )&& ($umurBulan < 24))
				{
					if(($berat < 4.1))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 4.2) && ($berat <= 8.7))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 8.8) && ($berat < 13.7))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}

				//  Usia 14 bulan: 8,1—11,3 kg.
				// 2 tahun: 9,7–15,3 kg
				elseif(($umurBulan > 24) && ($umurBulan < 30))
				{
					if(($berat < 4.1))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 4.2) && ($berat <= 9.7))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 9.7) && ($berat < 15.3))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}

				//  Usia 15 bulan: 8,3—11,5 kg.
				// 2 tahun, 6 bulan: 10,5–16,9 kg
				elseif(($umurBulan > 30 )&&( $umurBulan < 36))
				{
					if(($berat < 5))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 5.1) && ($berat <= 10.5))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 10.5) && ($berat < 16.9))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}

				// 3 tahun: 11,3–18,3 kg
				elseif(($umurBulan > 36) && ($umurBulan < 42))
				{
					if(($berat < 5))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 5.1) && ($berat <= 11.2))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 11.3) && ($berat < 18.3))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}


				// 3 tahun, 6 bulan: 12–19,7 kg
				elseif(($umurBulan > 42) && ($umurBulan < 48))
				{
					if(($berat < 6))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 6.1) && ($berat <= 11.9))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 12) && ($berat < 19.7))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}

				// 4 tahun: 12,7–21,2 kg
				elseif(($umurBulan > 48) && ($umurBulan < 53))
				{
					if(($berat < 6))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 6.1) && ($berat <= 12.6))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 12.7) && ($berat < 21.2))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}


				// 5 tahun: 14,1–24,2 kg
				elseif(($umurBulan > 53) && ($umurBulan < 60))
				{
					if(($berat < 6))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 6.1) && ($berat <= 14))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 14.1) && ($berat < 24.2))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}

				// 6 tahun: 15,9 kg–27,1 kg
				elseif(($umurBulan > 60) && ($umurBulan < 72))
				{
					if(($berat < 7))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 7.1) && ($berat <= 15.8))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 15.9 ) && ($berat < 27.1))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}

				// 7 tahun: 17,7 kg–30,7 kg
				elseif(($umurBulan > 84) && ($umurBulan < 96))
				{
					if(($berat < 7))
					{
						$statusBB = 'Berat badan sangat kurang';
					} elseif(($berat >= 7.1) && ($berat <= 17.1))
					{
						$statusBB = 'Berat badan kurang';
					} elseif (($berat > 17.1 ) && ($berat < 30.7))
					{
						$statusBB = 'Berat badan normal';
					} else $statusBB = 'Risiko berat badan berlebih';
					// menampilkan di table
					return $statusBB;
				}	
		    
		} 

					
	}
	
	static function statusPBU_OLD ($berat, $umur, $tinggi ){
    	if($umur <> '' || $berat <> '' || $tinggi <> '') 
        {
        	$umurBulan = round($umur/30,2);

            //  Usia 0 bulan atau baru lahir: 46,1-55,6 sentimeter (cm)
			if($umurBulan <= 1)
			{
				if(($tinggi <= 40))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 40.1) && ($tinggi <= 46.1))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 46.1) && ($tinggi <= 55.6))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //  Usia 1 bulan: 50,8-60,6 cm
			elseif(($umurBulan > 1) && ($umurBulan <= 2))
			{
				if(($tinggi <= 40.1))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 40.1) && ($tinggi <= 50.7))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 50.8) && ($tinggi <= 60.6))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //  Usia 2 bulan: 54,4-64,4 cm
			elseif(($umurBulan > 2) &&( $umurBulan <= 3))
			{
				if(($tinggi <= 40.4))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 40.5) && ($tinggi <= 54.3))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 54.4) && ($tinggi <= 64.4))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //  Usia 3 bulan: 57,3-67,6 cm
			elseif(($umurBulan > 3) && ($umurBulan <= 4))
			{
				if(($tinggi <= 40.3))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 40.4) && ($tinggi <= 57.2))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 57.3) && ($tinggi <= 67.6))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //  Usia 4 bulan: 59,7-70,1 cm
			elseif(($umurBulan > 4) && ($umurBulan <= 5))
			{
				if(($tinggi <= 40.7))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 40.8) && ($tinggi <= 59.6))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 59.7) && ($tinggi <= 70.1))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 5 bulan: 61,7-72,2 cm
			elseif(($umurBulan > 5) && ($umurBulan <= 6))
			{
				if(($tinggi <= 44.7))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 44.8) && ($tinggi <= 61.6))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 61.7) && ($tinggi <= 72.2))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 6 bulan: 63,6-74,0 cm
			elseif(($umurBulan > 6) && ($umurBulan <= 7))
			{
				if(($tinggi <= 50.6))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 50.5) && ($tinggi <= 63.5))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 63.6) && ($tinggi <= 74.0))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 7 bulan: 64,8-75,5 cm
			elseif(($umurBulan > 7) && ($umurBulan <= 8))
			{
				if(($tinggi <= 54.4))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 50.5) && ($tinggi <= 64.8))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 64.8) && ($tinggi <= 75.5))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 8 bulan: 66,2- 77,2 cm
			elseif(($umurBulan > 8) && ($umurBulan <= 9))
			{
				if(($tinggi <= 50.2))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 50.3) && ($tinggi <= 66.1))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 66.2) && ($tinggi <= 77.2))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 9 bulan: 67,5-78,7 cm
			elseif(($umurBulan > 9) && ($umurBulan <= 10))
			{
				if(($tinggi <= 55.4))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 55.5) && ($tinggi <= 67.4))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 67.5) && ($tinggi <= 78.7))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 10 bulan: 68,7-80,1 cm
			elseif(($umurBulan > 10) && ($umurBulan <= 11))
			{
				if(($tinggi <= 58.7))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 58.5) && ($tinggi <= 68.6))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 68.7) && ($tinggi <= 80.1))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 11 bulan: 69,9-81,5 cm
			elseif(($umurBulan > 11) && ($umurBulan <= 12))
			{
				if(($tinggi <= 58.9))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 60) && ($tinggi <= 69.8))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 69.9) && ($tinggi <= 81.5))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 12 bulan: 71,0-82,9 cm
			elseif(($umurBulan > 12) && ($umurBulan <= 13))
			{
				if(($tinggi <= 69.0))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 61) && ($tinggi <= 69.9))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 71.0) && ($tinggi <= 82.9))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 13 bulan: 72,1-84,2cm
			elseif(($umurBulan > 13) && ($umurBulan <= 14))
			{
				if(($tinggi <= 60.1))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 61) && ($tinggi <= 70))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 72.1) && ($tinggi <= 84.2))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 14 bulan: 73,1-85,5 cm
			elseif(($umurBulan > 14) && ($umurBulan <= 15))
			{
				if(($tinggi <= 61.1))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 61.2) && ($tinggi <= 73))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 73.1) && ($tinggi <= 85.51))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 15 bulan: 74,1-86,7 cm
			elseif(($umurBulan > 15) && ($umurBulan <= 16))
			{
				if(($tinggi <= 64.1))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 64.2) && ($tinggi <= 74))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 74.1) && ($tinggi <= 86.7))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 16 bulan: 75,0-88,0 cm
			elseif(($umurBulan > 16) && ($umurBulan <= 17))
			{
				if(($tinggi <= 64.1))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 64.2) && ($tinggi <= 74))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 75.0) && ($tinggi <= 88.0))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 17 bulan: 76,0-89,2 cm
			elseif(($umurBulan > 17) && ($umurBulan <= 18))
			{
				if(($tinggi <= 64.1))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 64.2) && ($tinggi <= 76))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 76.0) && ($tinggi <= 89.2))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 18 bulan: 76,9-90,4 cm
			elseif(($umurBulan >= 18) && ($umurBulan <= 19))
			{
				if(($tinggi <= 64.1))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 64.2) && ($tinggi <= 76.8))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 76.9) && ($tinggi <= 90.4))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 19 bulan: 77,7-91,5 cm
			elseif(($umurBulan >= 19) && ($umurBulan <= 20))
			{
				if(($tinggi <= 64.1))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 64.2) && ($tinggi <= 77.6))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 77.7) && ($tinggi <= 91.5))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 20 bulan: 78,6-92,6 cm
			elseif(($umurBulan >= 20) && ($umurBulan <= 21))
			{
				if(($tinggi <= 64.1))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 64.2) && ($tinggi <= 78.6))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 78.6) && ($tinggi <= 92.6))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 21 bulan: 79,4-93,8 cm
			elseif(($umurBulan >= 21) && ($umurBulan <= 22))
			{
				if(($tinggi <= 64.1))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 64.2) && ($tinggi <= 79.3))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 79.4) && ($tinggi <= 93.8))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 22 bulan: 80,2-94,9 cm
			elseif(($umurBulan >= 22) && ($umurBulan <= 23))
			{
				if(($tinggi <= 64.1))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 64.2) && ($tinggi <= 80.1))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 80.2) && ($tinggi <= 94.9))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

            //Usia 23 bulan: 81,0-95,9 cm
			elseif(($umurBulan >= 23) && ($umurBulan <= 24))
			{
				if(($tinggi <= 74.1))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 74.2) && ($tinggi <= 80.9))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 81.0) && ($tinggi <= 95.9))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;

			}

        	//Usia 24 bulan: 81,7-97,0 cm
			elseif(($umurBulan >= 24 )&& ($umurBulan <= 25))
			{
				if(($tinggi <= 74.1))
				{
					$statusPBU = 'Sangat Pendek';
				} elseif (($tinggi >= 74.2) && ($tinggi <= 81.6))
				{
					$statusPBU = 'Pendek';
				} elseif (($tinggi >= 81.7) && ($tinggi <= 97))
				{
					$statusPBU = 'Normal';
				} else $statusPBU = 'Tinggi';
				//menampilkan status PBU di tabel data balita
				return $statusPBU;	
			}
		
	}

		else return 'Tinggi badan tidak masuk ke kategori manapun';
	}


    
	static function statusBBPB_OLD($umur, $berat,$tinggi  ) {
		
		
		
		
		
		
		

// Thinnes atau gizi kurang= -3 SD sampai
// Normal atau gizi baik= -2 SD sd +1 SD
// Overweight atau gizi lebih= +1 SD sd +2 SD
// Obesitas= >+2 SD

		if($umur <> '' || $berat <> '' || $tinggi <> '') 
        {
        	$umurBulan = round($umur/30,2);
            
			//Usia 0 bulan atau baru lahir: 2,5-3,9 kilogram (kg)
			if($umurBulan <= 2)
			{
				if(($berat <= 2))
				{
					$statusBBPB = 'Gizi buruk ';
				} 
				elseif (($berat >= 2.1) && ($berat <= 2.4))
					{
						$statusBBPB = 'Gizi kurang';
					} 
					elseif (($berat >= 2.5) && ($berat <= 3.9))
					{
						$statusBBPB = 'Gizi baik ';
					} 
						elseif (($berat >= 4) && ($berat <= 5.8))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 5.9) && ($berat <= 6.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';

				return $statusBBPB;

			}

            // Usia 1 bulan: 3,4-5,1 kg
			elseif(($umurBulan > 1) && ($umurBulan <= 2))
			{
				if(($berat <= 2))
				{
					$statusBBPB = 'Gizi buruk ';
				} 
					elseif (($berat >= 2.1) && ($berat <= 3.3))
					{
						$statusBBPB = 'Gizi kurang ';
					} 
						elseif (($berat >= 3.4) && ($berat <= 5.1))
						{
							$statusBBPB = 'Gizi baik';
						} 
							elseif (($berat >= 5.2) && ($berat <= 6.2))
							{
								$statusBBPB = 'Berisiko gizi lebih';
							}  
								elseif (($berat >= 6.3) && ($berat <= 7.2))
								{
									$statusBBPB = 'Gizi lebih';
								} else $statusBBPB = 'Obesitas';
					
				return $statusBBPB;

			}
		
			// Usia 2 bulan: 4,3-6,3 kg
			elseif(($umurBulan > 2) && ($umurBulan <= 3))
			{
				if(($berat <= 3))
				{
					$statusBBPB = 'Gizi buruk';
				} 

				elseif (($berat >= 3.1) && ($berat <= 5))
				{
					$statusBBPB = 'Gizi kurang';
				} 
					elseif (($berat >= 4.3) && ($berat <= 6.3))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 6.4) && ($berat <= 7.3))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 7.4) && ($berat <= 8.2))
							{
								$statusBBPB = 'Gizi lebih';
							} 
								elseif (($berat >= 8.3) && ($berat <= 9.2))
								{
									$statusBBPB = 'Gizi lebih';
								} else $statusBBPB = 'Obesitas';
					
					return $statusBBPB;

			}
		
			// Usia 3 bulan: 5,0-7,2 kg
			elseif(($umurBulan > 3) && ($umurBulan <= 4))
			{
				if(($berat <= 4))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 4.1) && ($berat <= 5))
				{
					$statusBBPB = 'Gizi kurang';
				} 
					elseif (($berat >= 5.1) && ($berat <= 7.2))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 5.1) && ($berat <= 7.3))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 7.4) && ($berat <= 8.2))
							{
								$statusBBPB = 'Gizi lebih';
							} 
							else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}
		
			// Usia 4 bulan: 5,6-7,8 kg
			elseif(($umurBulan > 3) && ($umurBulan <= 4))
			{
				if(($berat <= 4.6))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 4.7) && ($berat <= 5.5))
				{
					$statusBBPB = 'Gizi kurang';
				} 
					elseif (($berat >= 4.6) && ($berat <= 7.8))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 7.9) && ($berat <= 8.8))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 9.9) && ($berat <= 10.8))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}

			// Usia 5 bulan: 6,0-8,4 kg
			elseif(($umurBulan > 5) && ($umurBulan <= 6))
			{
				if(($berat <= 5))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 5.1) && ($berat <= 5.9))
				{
					$statusBBPB = 'Gizi kurang';
				} 
					elseif (($berat >= 6) && ($berat <= 8.4))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 8.5) && ($berat <= 9.4))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 9.5) && ($berat <= 10.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}

			// Usia 6 bulan: 6,4-8,8 kg
			elseif(($umurBulan > 6) && ($umurBulan <= 7))
			{
				if(($berat <= 5))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 5.1) && ($berat <= 5.9))
				{
					$statusBBPB = 'Gizi kurang';
				} 
					elseif (($berat >= 6.4) && ($berat <= 8.8))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 8.9) && ($berat <= 9.8))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 8.9) && ($berat <= 10.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}
			
			// Usia 7 bulan: 6,7-9,2 kg
			elseif(($umurBulan > 7) && ($umurBulan <= 8))
			{
				if(($berat <= 5.1))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 5.2) && ($berat <= 6.6))
				{
					$statusBBPB = 'Gizi kurang';
				} 
					elseif (($berat >= 6.7) && ($berat <= 9.2))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 9.3) && ($berat <= 11.8))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 11.9) && ($berat <= 13.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}
			
			// Usia 7 bulan: 6,7-9,2 kg
			elseif(($umurBulan > 7) && ($umurBulan <= 8))
			{
				if(($berat <= 5.1))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 5.2) && ($berat <= 6.6))
				{
					$statusBBPB = 'Gizi kurang';
				} 
					elseif (($berat >= 6.7) && ($berat <= 9.2))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 9.3) && ($berat <= 11.8))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 11.9) && ($berat <= 13.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}
			
			// Usia 8 bulan: 6,9-9,6 kg
			elseif(($umurBulan > 8) && ($umurBulan <= 9))
			{
				if(($berat <= 5.1))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 5.2) && ($berat <= 6.6))
				{
					$statusBBPB = 'Gizi kurang';
				} 
					elseif (($berat >= 6.9) && ($berat <= 9.6))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 9.7) && ($berat <= 12.2))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 12.3) && ($berat <= 14.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}
			
			// Usia 9 bulan: 7,1-9,9 kg
			elseif(($umurBulan > 9) && ($umurBulan <= 10))
			{
				if(($berat <= 5.1))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 5.2) && ($berat <= 6.6))
				{
					$statusBBPB = 'Gizi kurang';
				} 
					elseif (($berat >= 7.1) && ($berat <= 9.9))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 10) && ($berat <= 13.2))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 13.3) && ($berat <= 15.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}
			
		// Usia 10 bulan: 7,4-10,2 kg
		    elseif(($umurBulan > 10) && ($umurBulan <= 11))
			{
				if(($berat <= 5.4))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 5.5) && ($berat <= 6.6))
				{
					$statusBBPB = 'Gizi kurang';
					
				} 
					elseif (($berat >= 7.4) && ($berat <= 9.9))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 10) && ($berat <= 13.2))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 13.3) && ($berat <= 15.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}
		// Usia 11 bulan: 7,6-10,5 kg
			 elseif(($umurBulan > 10) && ($umurBulan <= 11))
			{
				if(($berat <= 5.4))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 5.5) && ($berat <= 6.6))
				{
					$statusBBPB = 'Gizi kurang';
					
				} 
					elseif (($berat >= 7.4) && ($berat <= 9.9))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 10) && ($berat <= 13.2))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 13.3) && ($berat <= 15.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}
		// Usia 12 bulan: 7,7-10,8 kg
			 elseif(($umurBulan > 11) && ($umurBulan <= 12))
			{
				if(($berat <= 5.4))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 5.5) && ($berat <= 6.6))
				{
					$statusBBPB = 'Gizi kurang';
					
				} 
					elseif (($berat >= 7.7) && ($berat <= 10.8))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 10.9) && ($berat <= 13.2))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 13.3) && ($berat <= 15.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}
		// Usia 13 bulan: 7,9-11,0 kg
			elseif(($umurBulan > 12) && ($umurBulan <= 13))
			{
				if(($berat <= 5.4))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 5.5) && ($berat <= 7.9))
				{
					$statusBBPB = 'Gizi kurang';
					
				} 
					elseif (($berat >= 7.9) && ($berat <= 11))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 11.1) && ($berat <= 13.2))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 13.3) && ($berat <= 15.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}
		// Usia 14 bulan: 8,1-11,3 kg
			elseif(($umurBulan > 13) && ($umurBulan <= 14))
			{
				if(($berat <= 5.4))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 5.5) && ($berat <= 8))
				{
					$statusBBPB = 'Gizi kurang';
					
				} 
					elseif (($berat >= 8.1) && ($berat <= 11.3))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 11.4) && ($berat <= 13.2))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 13.3) && ($berat <= 15.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}
		// Usia 15 bulan: 8,3-11,5 kg
			elseif(($umurBulan > 14) && ($umurBulan <= 15))
			{
				if(($berat <= 5.4))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 5.5) && ($berat <= 8.2))
				{
					$statusBBPB = 'Gizi kurang';
					
				} 
					elseif (($berat >= 8.3) && ($berat <= 11.5))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 11.6) && ($berat <= 13.2))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 13.3) && ($berat <= 15.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}
		// Usia 16 bulan: 8,4-13,1 kg
			elseif(($umurBulan > 15) && ($umurBulan <= 16))
			{
				if(($berat <= 5.4))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 5.5) && ($berat <= 8.2))
				{
					$statusBBPB = 'Gizi kurang';
					
				} 
					elseif (($berat >= 8.3) && ($berat <= 11.3))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 11.4) && ($berat <= 13.2))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 13.3) && ($berat <= 15.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}
		// Usia 17 bulan: 8,6-12,0 kg
			elseif(($umurBulan > 16) && ($umurBulan <= 17))
			{
				if(($berat <= 6.4))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 6.5) && ($berat <= 12))
				{
					$statusBBPB = 'Gizi kurang';
					
				} 
					elseif (($berat >= 8.6) && ($berat <= 12.1))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 11.4) && ($berat <= 13.2))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 13.3) && ($berat <= 15.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}
		// Usia 18 bulan: 8,8-12,2 kg
			elseif(($umurBulan > 16) && ($umurBulan <= 17))
			{
				if(($berat <= 6.4))
				{
					$statusBBPB = 'Gizi buruk';
				} 
				elseif (($berat >= 6.5) && ($berat <= 12))
				{
					$statusBBPB = 'Gizi kurang';
					
				} 
					elseif (($berat >= 8.6) && ($berat <= 12.1))
					{
						$statusBBPB = 'Gizi baik';
					} 
						elseif (($berat >= 11.4) && ($berat <= 13.2))
						{
							$statusBBPB = 'Berisiko gizi lebih';
						} 
							elseif (($berat >= 13.3) && ($berat <= 15.2))
							{
								$statusBBPB = 'Gizi lebih';
							} else $statusBBPB = 'Obesitas';
				
				return $statusBBPB;

			}
		// Usia 19 bulan: 8,9-12,5 kg
		// Usia 20 bulan: 9,1-12,7 kg
		// Usia 21 bulan: 9,2-12,9 kg
		// Usia 22 bulan: 9,4-13,2 kg
		// Usia 23 bulan: 9,5-13,4 kg
		// Usia 24 bulan: 9,7-13,6 kg
			
			
			
			
        }
	}
	
	
}
