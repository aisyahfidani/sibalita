<?php
        
// Start Routes for databalita 
Route::resource('services/databalita','Services\DatabalitaController');
// End Routes for databalita 

                    
// Start Routes for datadesa 
Route::resource('services/datadesa','Services\DatadesaController');
// End Routes for datadesa 

                    
// Start Routes for bbpb 
Route::resource('services/bbpb','Services\BbpbController');
// End Routes for bbpb 

                    
// Start Routes for bbu 
Route::resource('services/bbu','Services\BbuController');
// End Routes for bbu 

                    
// Start Routes for pbu 
Route::resource('services/pbu','Services\PbuController');
// End Routes for pbu 

                    
// Start Routes for posyandu 
Route::resource('services/posyandu','Services\PosyanduController');
// End Routes for posyandu 

                    
// Start Routes for vposyandu 
Route::resource('services/vposyandu','Services\VposyanduController');
// End Routes for vposyandu 

                    
// Start Routes for bidan 
Route::resource('services/bidan','Services\BidanController');
// End Routes for bidan 

                    ?>