<?php
        
// Start Routes for databalita 
Route::resource('databalita','DatabalitaController');
// End Routes for databalita 

                    
// Start Routes for datadesa 
Route::resource('datadesa','DatadesaController');
// End Routes for datadesa 

                    
// Start Routes for bbpb 
Route::resource('bbpb','BbpbController');
// End Routes for bbpb 

                    
// Start Routes for bbu 
Route::resource('bbu','BbuController');
// End Routes for bbu 

                    
// Start Routes for pbu 
Route::resource('pbu','PbuController');
// End Routes for pbu 

                    
// Start Routes for posyandu 
Route::resource('posyandu','PosyanduController');
// End Routes for posyandu 

                    
// Start Routes for vposyandu 
Route::resource('vposyandu','VposyanduController');
// -- Post Method --

// End Routes for vposyandu 

                    
// Start Routes for bidan 
Route::resource('bidan','BidanController');
// End Routes for bidan 

                    ?>