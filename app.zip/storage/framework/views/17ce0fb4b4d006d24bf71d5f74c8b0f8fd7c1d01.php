<?php $__env->startSection('content'); ?>
<div class="page-header"><h2>  <?php echo e($pageTitle); ?> <small>Configuration</small> </h2></div>

	 
		<?php echo $__env->make('sximo.module.tab',array('active'=>'config','type'=> $type), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		
	<div class="row ">
			

	<div class="col-md-6">
	<?php echo Form::open(array('url'=>'sximo/module/saveconfig/'.$module_name, 'class'=>'form-horizontal ','id'=>'configA' , 'parsley-validate'=>'','novalidate'=>' ')); ?>

	<input  type='hidden' name='module_id' id='module_id'  value='<?php echo e($row->module_id); ?>'   />
  	<fieldset>
		<legend> Module Info </legend>	
  		<div class=" form-group row">
    		<label for="ipt" class=" control-label col-md-4">Name / Title </label>
			<div class="col-md-8">
				<div class="input-group input-group-sm" style="margin:1px 0 !important;">
				<input  type='text' name='module_title' id='module_title' class="form-control  form-control-sm " required="true" value='<?php echo e($row->module_title); ?>'  />
					
					<span class="input-group-addon xlick bg-default btn-sm" >EN</span>
				
			</div> 		
			<?php if($config->lang =='true'): ?>
			  <?php $lang = SiteHelpers::langOption();
			   if($sximoconfig['cnf_multilang'] ==1) {
				foreach($lang as $l) { if($l['folder'] !='en') {
			   ?>
			   <div class="input-group input-group-sm mb-1" >			   	
					 <input name="language_title[<?php echo $l['folder'];?>]" type="text"   class="form-control " placeholder="Label for <?php echo $l['name'];?>"
					 value="<?php echo (isset($module_lang['title'][$l['folder']]) ? $module_lang['title'][$l['folder']] : '');?>" />
						 
						<span class="input-group-addon xlick bg-default btn-sm" ><?php echo strtoupper($l['folder']);?></span>
					
			   </div> 
	 		
 			 <?php } } }?>	  
 			  <?php endif; ?>
			 </div> 
			
  		</div>   

		<div class=" form-group row">
			<label for="ipt" class=" control-label col-md-4">Module Note</label>
			<div class="col-md-8">
				<div class="input-group input-group-sm" style="margin:1px 0 !important;">
				<input  type='text' name='module_note' id='module_note'  value='<?php echo e($row->module_note); ?>' class="form-control form-control-sm "  />
				<span class="input-group-addon xlick bg-default btn-sm" >EN</span>
			</div> 
			<?php if($config->lang =='true'): ?>	
		  <?php $lang = SiteHelpers::langOption();
		   if($sximoconfig['cnf_multilang'] ==1) {
			foreach($lang as $l) { if($l['folder'] !='en') {
		   ?>
		   <div class="input-group input-group-sm" style="margin:1px 0 !important;">
			 <input name="language_note[<?php echo $l['folder'];?>]" type="text"   class="form-control " placeholder="Note for <?php echo $l['name'];?>"
			 value="<?php echo (isset($module_lang['note'][$l['folder']]) ? $module_lang['note'][$l['folder']] : '');?>" />
			 <span class="input-group-addon xlick bg-default btn-sm" ><?php echo strtoupper($l['folder']);?></span>
		   </div> 
			 
		  <?php } } }?>	
		  	 <?php endif; ?>	

			 </div> 
		 </div>   
		
	  <div class=" form-group row">
		<label for="ipt" class=" control-label col-md-4">Class Controller </label>
		<div class="col-md-8">
		<input  type='text' name='module_name' id='module_name' readonly="1"  class="form-control form-control-sm" required value='<?php echo e($row->module_name); ?>'  />
		 </div> 
	  </div>  
  
	   <div class=" form-group row">
		<label for="ipt" class=" control-label col-md-4">Table Master</label>
		<div class="col-md-8">
		<input  type='text' name='module_db' id='module_db' readonly="1"  class="form-control form-control-sm" required value='<?php echo e($row->module_db); ?>'  />
		  
		 </div> 
	  </div>  
  
	  <div class=" form-group row" style="display:none;" >
		<label for="ipt" class=" control-label col-md-4">Author </label>
		<div class="col-md-8">
		<input  type='text' name='module_author' id='module_author' class="form-control form-control-sm"  readonly="1"  value='<?php echo e($row->module_author); ?>'  />
		 </div> 
	  </div>  

		<div class=" form-group row">
			<label for="ipt" class=" control-label col-md-4"> ShortCode </label>
			<div class="col-md-8 " >
				
						<b>Form Shortcode : </b><code><br /><?php echo "[sc:Sximo fnc=showForm|id=".$row->module_name."] [/sc]"; ?></code><br />
					<b>Table Shortcode : </b><br />
					<code><?php echo "[sc:Sximo fnc=render|id=".$row->module_name."] [/sc]"; ?></code>
			</div> 
		</div>  	  
	 
		<div class=" form-group row">
			<label for="ipt" class=" control-label col-md-4"></label>
			<div class="col-md-8">
			<button type="submit" name="submit" class="btn btn-primary btn-sm"> Update Module </button>
			 </div> 
		</div>   



	</fieldset>
  	<?php echo Form::close(); ?>

	
  
	</div>


	 <?php if($config->advance =='true'): ?> 
 <div class="col-sm-6 col-md-6"> 

 <?php if($type !='report' && $type !='generic'): ?>
  <?php echo Form::open(array('url'=>'sximo/module/savesetting/'.$module_name, 'class'=>'form-horizontal  ' ,'id'=>'configB')); ?>

  <input  type='text' name='module_id' id='module_id'  value='<?php echo e($row->module_id); ?>'  style="display:none; " />
  	<fieldset>
		<legend> Module Setting </legend>

		  <div class=" form-group row">
			<label for="ipt" class=" control-label col-md-4"> Grid Table Type </label>
			<div class="col-md-8">			

				<select class="form-control form-control-sm" name="module_type">
					<?php if($row->module_type  =='addon') $row->module_type ='native'; ?>
					<?php $__currentLoopData = $cruds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($crud->type); ?>" 
						<?php if($crud->type == $row->module_type ): ?> selected <?php endif; ?>
						><?php echo e($crud->name); ?> </option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>	
				
			 </div> 
		  </div> 


	
	  <div class=" form-group row">
		<label for="ipt" class=" control-label col-md-4"> Default Order  </label>
		<div class="col-md-8">
			<select class="form-control  form-control-sm" name="orderby" style="width: 50%">
			<?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($t['field']); ?>"
				<?php if($setting['orderby'] ==$t['field']): ?> selected="selected" <?php endif; ?> 
				><?php echo e($t['label']); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
			<select class="form-control  form-control-sm" name="ordertype" style="width: 50%">
				<option value="asc" <?php if($setting['ordertype'] =='asc'): ?> selected="selected" <?php endif; ?> > Ascending </option>
				<option value="desc" <?php if($setting['ordertype'] =='desc'): ?> selected="selected" <?php endif; ?> > Descending </option>
			</select>
			
		 </div> 
	  </div> 
	  
	  <div class=" form-group row">
		<label for="ipt" class=" control-label col-md-4"> Display Rows </label>
		<div class="col-md-8">
			<select class="form-control  form-control-sm" name="perpage" style="width: 50%">
				<?php $pages = array('10','20','30','50');
				foreach($pages as $page) {
				?>
				<option value="<?php echo $page;?>"  <?php if($setting['perpage'] ==$page): ?> selected="selected" <?php endif; ?> > <?php echo $page;?> </option>
				<?php } ?>
			</select>	
			
		 </div> 
	  </div>   
		
	</fieldset>	
	 <?php if($config->setting->method =='true'): ?> 
  	<fieldset>
	<legend> Form & View Setting </legend>
		<p> <i>You can switch this setting and applied to current module without have to rebuild </i></p>

		  <div class=" form-group row">
			<label for="ipt" class=" control-label col-md-4"> Form Method </label>
			<div class="col-md-8">
				
				<input type="radio" value="native" name="form-method" class="filled-in" id="n-p" 
				 <?php if($setting['form-method'] == 'native'): ?> checked="checked" <?php endif; ?> 
				 /> 
				 <label for="n-p"> New Page </label>
				
				<input type="radio" value="modal" name="form-method"  class="filled-in" id="n-m" 
				 <?php if($setting['form-method'] == 'modal'): ?> checked="checked" <?php endif; ?> 			
				/> 
				<label for="n-m">	Modal  </label>							
			 </div> 
		  </div> 

		  <div class=" form-group row">
			<label for="ipt" class=" control-label col-md-4"> View  Method </label>
			<div class="col-md-8">
				
				<input type="radio" value="native" name="view-method" class="filled-in" id="v-n" 
				 <?php if($setting['view-method'] == 'native'): ?> checked="checked" <?php endif; ?> 
				 /> 
				 <label for="v-n">	New Page  </label>		
				
				<input type="radio" value="modal" name="view-method" class="filled-in" id="v-m"   
				 <?php if($setting['view-method'] == 'modal'): ?> checked="checked" <?php endif; ?> 			
				/> 
				 <label for="v-m">	Modal  </label>	   
				
				<input type="radio" value="expand" name="view-method"  class="filled-in" id="v-e" 
				 <?php if($setting['view-method'] == 'expand'): ?> checked="checked" <?php endif; ?> 			
				/>  
				 <label for="v-e">	Expand Grid    </label>	  

			 </div> 
		  </div> 		  

		  <div class=" form-group row" >
			<label for="ipt" class=" control-label col-md-4"> Inline add / edit row </label>
			<div class="col-md-8">
				
				<input type="checkbox" value="true" name="inline" class="filled-in" id="new-inline" 
				<?php if($setting['inline'] == 'true'): ?> checked="checked" <?php endif; ?> 	
				 /> 
				 <label for="new-inline"> Yes  Allowed </label>
										
			 </div> 
		  </div> 		  

		  
		   <p class="alert alert-warning"> <strong> Important ! </strong> this setting only work with module where have <strong>Adavance </strong> Option</p>
	</fieldset>


	<?php endif; ?>

			  <div class=" form-group row">
			<label for="ipt" class=" control-label col-md-4"></label>
			<div class="col-md-8">
			<button type="submit" name="submit" class="btn btn-primary btn-sm"> Update Setting </button>
			 </div> 
		  </div> 

	<?php echo Form::close(); ?>

	<?php endif; ?>
	
  </div>
  	<?php endif; ?>
</div>


<script type="text/javascript">
	$(document).ready(function(){

		<?php echo SximoHelpers::sjForm('configA'); ?>
		<?php echo SximoHelpers::sjForm('configB'); ?>

	})
</script>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/benuadi1/app_sibalita/resources/views/sximo/module/config.blade.php ENDPATH**/ ?>