<?php $__env->startSection('content'); ?>
<div class="page-header"><h2>  <?php echo e($pageTitle); ?> <small>Configuration</small> </h2></div>
 


          <?php echo $__env->make('sximo.module.tab',array('active'=>'sql','type'=>  $type ), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

         
          <?php echo Form::open(array('url'=>'sximo/module/savesql/'.$module_name, 'class'=>'form-vertical  ' ,'id'=>'SQL' , 'parsley-validate'=>'','novalidate'=>' ')); ?>

          <div class="infobox infobox-success ">
          <button type="button" class="close" data-dismiss="alert"> x </button>  
          <p> <strong>Tips !</strong> U can use query builder tool such <a href="http://code.google.com/p/sqlyog/downloads/list" target="_blank">SQL YOG </a> , PHP MyAdmin , Maestro etc to build your query statment and preview the result , <br /> then copy the syntac here </p> 
          </div>  


          <div class="form-group">
          <label for="ipt" class=" control-label">SQL SELECT & JOIN</label>
          <textarea name="sql_select" rows="5" id="sql_select" class="tab_behave form-control form-control-sm"  placeholder="SQL Select & Join Statement" ><?php echo e($sql_select); ?></textarea>
          </div>  

          <div class="form-group">
          <label for="ipt" class=" control-label">SQL WHERE CONDITIONAL</label>
          <textarea name="sql_where" rows="2" id="sql_where" class="form-control form-control-sm" placeholder="SQL Where Statement" ><?php echo e($sql_where); ?></textarea>
          </div> 

          <div class="infobox infobox-danger ">
          <p> <strong>Warning !</strong> Please make sure SQL where not empty , for prevent error when user attempt submit  <strong>SEARCH</strong>   </p>  
          </div>  
            


          <div class="form-group">
          <label for="ipt" class=" control-label">SQL GROUP</label>
          <textarea name="sql_group" rows="2" id="sql_group" class="form-control form-control-sm"   placeholder="SQL Grouping Statement" ><?php echo e($sql_group); ?></textarea>

          </div> 
          <div class="form-group">
          <label for="ipt" class=" control-label"></label>
          <button type="submit" class="btn btn-primary btn-sm"> Save SQL </button>
          </div>  

          <input type="hidden" name="module_id" value="<?php echo e($row->module_id); ?>" />
          <input type="hidden" name="module_name" value="<?php echo e($row->module_name); ?>" />

          <?php echo Form::close(); ?>



 
<script type="text/javascript">
  $(document).ready(function(){

    <?php echo SximoHelpers::sjForm('SQL'); ?>

  })
</script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/benuadi1/app_sibalita/resources/views/sximo/module/sql.blade.php ENDPATH**/ ?>