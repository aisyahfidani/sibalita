<?php

$tabs = array(
		'' 		        => ''. Lang::get('core.tab_siteinfo'),
		'email'			=> ' '. Lang::get('core.tab_email'),
		'security'		=> ' '. Lang::get('core.tab_loginsecurity') ,
		'translation'	=>' '.Lang::get('core.tab_translation')
	);

?>
<div class="p-2">
<ul class="nav nav-tabs" class="p-2">
<?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li class="nav-item">
		 <a class="nav-link <?php if($key == $active): ?> active <?php endif; ?>" href="<?php echo e(URL::to('sximo/config/'.$key)); ?>"><?php echo $val; ?> </a>
	</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>
</div><?php /**PATH /home/benuadi1/app_sibalita/resources/views/sximo/config/tab.blade.php ENDPATH**/ ?>