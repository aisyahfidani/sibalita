<?php $__env->startSection('content'); ?>
<div class="page-titles">
  <h2> <?php echo e($pageTitle); ?> <small> <?php echo e($pageNote); ?> </small></h2>
</div>
<div class="card">
	<div class="card-body">


	<?php echo Form::open(array('url'=>'pbu?return='.$return, 'class'=>'form-horizontal  validated sximo-form','files' => true ,'id'=> 'FormTable' )); ?>

	<div class="toolbar-nav">
		<div class="row">
			<div class="col-md-6 " >
				 <a href="<?php echo e(url($pageModule.'?return='.$return)); ?>" class="tips btn btn-danger  btn-sm "  title="<?php echo e(__('core.btn_back')); ?>" ><i class="fa  fa-times"></i></a>
			</div>
			<div class="col-md-6  text-right " >
				<div class="btn-group">
					
						<button name="apply" class="tips btn btn-sm btn-info  "  title="<?php echo e(__('core.btn_back')); ?>" > <?php echo e(__('core.sb_apply')); ?> </button>
						<button name="save" class="tips btn btn-sm btn-primary "  id="saved-button" title="<?php echo e(__('core.btn_back')); ?>" > <?php echo e(__('core.sb_save')); ?> </button> 
						
					
				</div>		
			</div>
			
		</div>
	</div>	


	
	<ul class="parsley-error-list">
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>		
	<div class="">
		<div class="col-md-12">
						<fieldset><legend> Data PBU</legend>
				<?php echo Form::hidden('id', $row['id']); ?>					
									  <div class="form-group row  " >
										<label for="Panjang Tinggi Badan" class=" control-label col-md-4 "> Panjang Tinggi Badan </label>
										<div class="col-md-8">
										  <input  type='text' name='panjang_tinggi_badan' id='panjang_tinggi_badan' value='<?php echo e($row['panjang_tinggi_badan']); ?>' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> </fieldset></div>

	</div>
	
	<input type="hidden" name="action_task" value="save" />
	<?php echo Form::close(); ?>

	</div>
</div>
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		 	
		 	 

		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '<?php echo e(url("pbu/removefiles?file=")); ?>'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/benuadi1/app_sibalita/resources/views/pbu/form.blade.php ENDPATH**/ ?>