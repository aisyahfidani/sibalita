<?php $sidebar = SiteHelpers::menus('sidebar') ;
$active = Request::segment(1);
?>
<aside class="left-sidebar ">
    <div class="sidebar-profile" >
        <div class="row">
            <div class="col-3">
                <?php echo SiteHelpers::avatar( 42 ); ?>

            </div>
            <div class="col-9">
                <a href="<?php echo e(url('user/profile')); ?>">
                    <b><?php echo e(Session::get('fid')); ?></b>
                    <p><?php echo e(Session::get('eid')); ?> </p>
                </a>
            </div>
        </div>    
    </div>
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                <?php $__currentLoopData = $sidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   

                    <?php if($menu['module'] =='separator'): ?>
                      <li class="nav-small-cap"> <span> <?php echo e($menu['menu_name']); ?> </span></li>  

                    <?php else: ?>
                    <li>
                        <?php if(count($menu['childs']) > 0 ): ?> 
                            <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false">
                                <i class="<?php echo e($menu['menu_icons']); ?>"></i>
                                <span class="hide-menu">
                                    <?php echo e((isset($menu['menu_lang']['title'][session('lang')]) ? $menu['menu_lang']['title'][session('lang')] : $menu['menu_name'])); ?>

                                </span>
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(url($menu['module'])); ?>" >
                                    <i class="<?php echo e($menu['menu_icons']); ?>"></i>
                                    <span class="hide-menu">
                                        <?php echo e((isset($menu['menu_lang']['title'][session('lang')]) ? $menu['menu_lang']['title'][session('lang')] : $menu['menu_name'])); ?>

                                    </span>
                            </a>                               

                        <?php endif; ?> 

                            <!-- LEVEL 2 -->
                         <?php if(count($menu['childs']) > 0 ): ?> 
                            <ul aria-expanded="false" >
                             <?php $__currentLoopData = $menu['childs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <li>
                                    <?php if(count($menu2['childs']) > 0 ): ?>
                                    <a class="has-arrow" href="#" aria-expanded="false">
                                        <?php echo e((isset($menu2['menu_lang']['title'][session('lang')]) ? $menu2['menu_lang']['title'][session('lang')] : $menu2['menu_name'])); ?>

                                    </a>
                                    <?php else: ?> 
                                    <a href="<?php echo e(url($menu2['module'])); ?>">
                                        <?php echo e((isset($menu2['menu_lang']['title'][session('lang')]) ? $menu2['menu_lang']['title'][session('lang')] : $menu2['menu_name'])); ?>

                                    </a>

                                    <?php endif; ?>

                                    <?php if(count($menu2['childs']) > 0 ): ?>
                                        <ul aria-expanded="false" >
                                            <?php $__currentLoopData = $menu2['childs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <li>
                                                    <a href="<?php echo e(url($menu3['module'])); ?>">
                                                        <?php echo e((isset($menu3['menu_lang']['title'][session('lang')]) ? $menu3['menu_lang']['title'][session('lang')] : $menu3['menu_name'])); ?>

                                                    </a>
                                                  </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    


                                        </ul>


                                    <?php endif; ?> 


                                </li>

                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul> 
                         <?php endif; ?>


                    </li>      
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        

            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside><?php /**PATH /home/benuadi1/app_sibalita/resources/views/layouts/leftnav.blade.php ENDPATH**/ ?>