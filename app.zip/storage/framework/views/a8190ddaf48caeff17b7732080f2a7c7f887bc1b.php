

<?php $__env->startSection('content'); ?>

<div class="page-titles">
	<h4 class="mb-0">  <?php echo e($pageTitle); ?>  </h4>
</div>

<div class="card">
	
	<div class="card-body">

	


<div class="toolbar-nav">
	<div class="row">
		<div class="col-md-4 ">
			<div class="input-group">
			     
			      <input type="text" class="form-control form-control-sm onsearch" data-target="<?php echo e(url($pageModule)); ?>" aria-label="..." placeholder=" Type And Hit Enter ">
			    </div>
		</div> 
		<div class="col-md-8 text-right"> 	
			<div class="btn-group">
				<?php if($access['is_add'] ==1): ?>
				<a href="<?php echo e(url('core/users/create?return='.$return)); ?>" class="btn  btn-sm btn-info"  
					title="<?php echo e(__('core.btn_create')); ?>"> Tambah </a>
				<?php endif; ?> 
				<div class="btn-group">
					<button type="button" class="btn  btn-sm btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Aksi lainnya </button>
			        <ul class="dropdown-menu">
			         <?php if($access['is_remove'] ==1): ?>
						 <li class="nav-item"><a href="javascript://ajax"  onclick="SximoDelete();" class="nav-link tips" title="<?php echo e(__('core.btn_remove')); ?>">
						Hapus </a></li>
					<?php endif; ?> 
			          
			        </ul>
			    </div>   
			    
			</div>	
		</div>
		 
	</div>	  
</div>					
			<!-- End Toolbar Top -->

			<!-- Table Grid -->
		<div class="table-responsive"> 
			
 			<?php echo Form::open(array('url'=>'core/users?'.$return, 'class'=>'form-horizontal m-t' ,'id' =>'SximoTable' )); ?>

 			
			
		    <table class="table table-striped  table-hover " id="<?php echo e($pageModule); ?>Table">
		        <thead>
					<tr>
						<th style="width: 3% !important;" class="number"> No </th>
						<th  style="width: 3% !important;"> 
							<input type="checkbox" class="checkall filled-in" id="checked-all"  />
							<label for="checked-all"></label>
						</th>
						
						
						<?php $__currentLoopData = $tableGrid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($t['view'] =='1'): ?>				
								<?php $limited = isset($t['limited']) ? $t['limited'] :''; 
								if(SiteHelpers::filterColumn($limited ))
								{
									$addClass='class="tbl-sorting" ';
									if($insort ==$t['field'])
									{
										$dir_order = ($inorder =='desc' ? 'sort-desc' : 'sort-asc'); 
										$addClass='class="tbl-sorting '.$dir_order.'" ';
									}
									echo '<th align="'.$t['align'].'" '.$addClass.' width="'.$t['width'].'">'.\SiteHelpers::activeLang($t['label'],(isset($t['language'])? $t['language'] : array())).'</th>';				
								} 
								?>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<th  style="width: 10% !important;"><?php echo e(__('core.btn_action')); ?></th>
					  </tr>
		        </thead>

		        <tbody>        						
		            <?php $__currentLoopData = $rowData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                <tr>
							<td > <?php echo e(++$i); ?> </td>
							<td >
								<input type="checkbox" class="ids filled-in" name="ids[]" value="<?php echo e($row->id); ?>" id="val-<?php echo e($row->id); ?>" /> 
								<label for="val-<?php echo e($row->id); ?>"></label>
							</td>
																					
						 <?php $__currentLoopData = $tableGrid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							 <?php if($field['view'] =='1'): ?>
							 	<?php $limited = isset($field['limited']) ? $field['limited'] :''; ?>
							 	<?php if(SiteHelpers::filterColumn($limited )): ?>
							 	 <?php $addClass= ($insort ==$field['field'] ? 'class="tbl-sorting-active" ' : ''); ?>
								 <td align="<?php echo e($field['align']); ?>" width=" <?php echo e($field['width']); ?>"  <?php echo $addClass; ?> >					 
								 	<?php echo SiteHelpers::formatRows($row->{$field['field']},$field ,$row ); ?>						 
								 </td>
								<?php endif; ?>	
							 <?php endif; ?>					 
						 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
						 <td>

							 	<div class="dropdown">
								  <button class="btn btn-sm dropdown-toggle" type="button" data-toggle="dropdown"> <?php echo e(__('core.btn_action')); ?> </button>
								  <ul class="dropdown-menu">
								 	
									<?php if($access['is_edit'] ==1): ?>
									<li class="nav-item"><a  href="<?php echo e(url('core/users/'.$row->id.'/edit?return='.$return)); ?>" class="nav-link tips" title="<?php echo e(__('core.btn_edit')); ?>"> <?php echo e(__('core.btn_edit')); ?> </a></li>
									<?php endif; ?>
									<div class="dropdown-divider"></div>
									<?php if($access['is_remove'] ==1): ?>
										 <li class="nav-item"><a href="javascript://ajax"  onclick="SximoDelete();" class="nav-link  tips" title="<?php echo e(__('core.btn_remove')); ?>">
										Remove Selected </a></li>
									<?php endif; ?> 
								  </ul>
								</div>

							</td>		 
		                </tr>
						
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		              
		        </tbody>
		      
		    </table>
		    
			<input type="hidden" name="action_task" value="" />
			
			<?php echo Form::close(); ?>

			
		</div>	
			<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<!-- End Table Grid -->
		</div>
	</div>		
</div>


<script>
$(document).ready(function(){
	$('.copy').click(function() {
		var total = $('input[class="ids"]:checkbox:checked').length;
		if(confirm('are u sure Copy selected rows ?'))
		{
			$('input[name="action_task"]').val('copy');
			$('#SximoTable').submit();// do the rest here	
		}
	})	
	
});	
</script>	
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/benuadi1/app_sibalita/resources/views/core/users/index.blade.php ENDPATH**/ ?>