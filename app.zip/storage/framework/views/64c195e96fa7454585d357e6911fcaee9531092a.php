<?php $__env->startSection('content'); ?>
<div class="page-titles">
  <h2> <?php echo e($pageTitle); ?> <small> <?php echo e($pageNote); ?> </small></h2>
</div>

<div class="card">
	<div class="card-body">
		<div class="toolbar-nav" >   
			<div class="row">
				<div class="col-md-4 col-4">
					<div class="input-group ">
					      
					      <input type="text" class="form-control form-control-sm onsearch" data-target="<?php echo e(url($pageModule)); ?>" aria-label="..." placeholder=" Ketik kemudian Enter ">
					    </div>
				</div> 
				<div class="col-md-8 col-8  text-right"> 	
					<div class="btn-group">
						<?php if($access['is_add'] ==1): ?>
						<a href="<?php echo e(url('datadesa/create?return='.$return)); ?>" class="btn  btn-sm btn-primary"  
							title="<?php echo e(__('core.btn_create')); ?>"><i class="fas fa-plus"></i> <?php echo e(__('core.btn_create')); ?></a>
						<?php endif; ?>
						<div class="btn-group">
							<button type="button" class="btn btn-sm btn-info dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fas fa-bars"></i> Aksi lainnya </button>
					        <ul class="dropdown-menu">
					        <?php if($access['is_remove'] ==1): ?>
								 <li class="nav-item"><a href="javascript://ajax"  onclick="SximoDelete();" class="nav-link tips" title="<?php echo e(__('core.btn_remove')); ?>">
								Hapus yang dicentang </a></li>
							<?php endif; ?> 
							
					          	
					        
					          
					        </ul>
					    </div>   
				    </div>
				</div>
				   
			</div>	

		</div>	

			<!-- Table Grid -->
			
 			<?php echo Form::open(array('url'=>'datadesa?'.$return, 'class'=>'form-horizontal m-t' ,'id' =>'SximoTable' )); ?>

			<div class="table-responsive">
		    <table class="table  table-hover table-striped  " id="<?php echo e($pageModule); ?>Table">
		        <thead>
					<tr>
						<th style="width: 3% !important;" class="number"> No </th>
						<th  style="width: 3% !important;"> 
							<input type="checkbox" class="checkall filled-in" id="checked-all"  />
							<label for="checked-all"></label>
						</th>
						
						
						<?php $__currentLoopData = $tableGrid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($t['view'] =='1'): ?>				
								<?php $limited = isset($t['limited']) ? $t['limited'] :''; 
								if(SiteHelpers::filterColumn($limited ))
								{
									$addClass='class="tbl-sorting" ';
									if($insort ==$t['field'])
									{
										$dir_order = ($inorder =='desc' ? 'sort-desc' : 'sort-asc'); 
										$addClass='class="tbl-sorting '.$dir_order.'" ';
									}
									echo '<th align="'.$t['align'].'" '.$addClass.' width="'.$t['width'].'">'.\SiteHelpers::activeLang($t['label'],(isset($t['language'])? $t['language'] : array())).'</th>';				
								} 
								?>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<th  style="width: 10% !important;"><?php echo e(__('core.btn_action')); ?></th>
						
					  </tr>
		        </thead>

		        <tbody>        						
		            <?php $__currentLoopData = $rowData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                <tr>
							<td class="thead"> <?php echo e(++$i); ?> </td>
							<td class="tcheckbox">
								<input type="checkbox" class="ids filled-in" name="ids[]" value="<?php echo e($row->id); ?>" id="val-<?php echo e($row->id); ?>" /> 
								<label for="val-<?php echo e($row->id); ?>"></label>
							</td>
																					
						 <?php $__currentLoopData = $tableGrid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							 <?php if($field['view'] =='1'): ?>
							 	<?php $limited = isset($field['limited']) ? $field['limited'] :''; ?>
							 	<?php if(SiteHelpers::filterColumn($limited )): ?>
							 	 <?php $addClass= ($insort ==$field['field'] ? 'class="tbl-sorting-active" ' : ''); ?>
								 <td align="<?php echo e($field['align']); ?>" width=" <?php echo e($field['width']); ?>"  <?php echo $addClass; ?> >					 
								 	<?php echo SiteHelpers::formatRows($row->{$field['field']},$field ,$row ); ?>						 
								 </td>
								<?php endif; ?>	
							 <?php endif; ?>					 
						 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
						 <td>

							 	<div class="dropdown">
								  <button class="btn dropdown-toggle" type="button" data-toggle="dropdown"><i class="fas fa-tasks"></i>  </button>
								  <ul class="dropdown-menu">
									<?php if($access['is_edit'] ==1): ?>
									<li class="nav-item"><a  href="<?php echo e(url('datadesa/'.$row->id.'/edit?return='.$return)); ?>" class="nav-link  tips" title="<?php echo e(__('core.btn_edit')); ?>"> <?php echo e(__('core.btn_edit')); ?> </a></li>
									<?php endif; ?>
									<div class="dropdown-divider"></div>
									<?php if($access['is_remove'] ==1): ?>
										<li class="nav-item"><a href="javascript://ajax"  onclick="SximoDelete();" class="nav-link  tips" title="<?php echo e(__('core.btn_remove')); ?>">
										Hapus </a></li>
									<?php endif; ?> 
								  </ul>
								</div>

							</td>		 
		                </tr>
						
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		              
		        </tbody>
		      
		    </table>
		    </div>
			<input type="hidden" name="action_task" value="" />
			
			<?php echo Form::close(); ?>

			
			
			<!-- End Table Grid -->

		</div>
		<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>		
</div>

<script>
$(document).ready(function(){
	$('.copy').click(function() {
		var total = $('input[class="ids"]:checkbox:checked').length;
		if(confirm('are u sure Copy selected rows ?'))
		{
			$('input[name="action_task"]').val('copy');
			$('#SximoTable').submit();// do the rest here	
		}
	})	
	
});	
</script>	
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/benuadi1/app_sibalita/resources/views/datadesa/index.blade.php ENDPATH**/ ?>