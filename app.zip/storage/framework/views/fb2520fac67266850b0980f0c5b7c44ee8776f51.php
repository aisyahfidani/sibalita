<?php $__env->startSection('content'); ?>
<div class="page-titles">
  <h2> <?php echo e($pageTitle); ?> <small> <?php echo e($pageNote); ?> </small></h2>
</div>
<div class="card">
	<div class="card-body">


	<?php echo Form::open(array('url'=>'databalita?return='.$return, 'class'=>'form-horizontal  validated sximo-form','files' => true ,'id'=> 'FormTable' )); ?>

	<div class="toolbar-nav">
		<div class="row">
			<div class="col-md-6 " >
				 <a href="<?php echo e(url($pageModule.'?return='.$return)); ?>" class="tips btn btn-danger  btn-sm "  title="<?php echo e(__('core.btn_back')); ?>" ><i class="fa  fa-times"></i></a>
			</div>
			<div class="col-md-6  text-right " >
				<div class="btn-group">
					
						<button name="apply" class="tips btn btn-sm btn-info  "  title="<?php echo e(__('core.btn_back')); ?>" > <?php echo e(__('core.sb_apply')); ?> </button>
						<button name="save" class="tips btn btn-sm btn-primary "  id="saved-button" title="<?php echo e(__('core.btn_back')); ?>" > <?php echo e(__('core.sb_save')); ?> </button> 
						
					
				</div>		
			</div>
			
		</div>
	</div>	


	
	<ul class="parsley-error-list">
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>		
	<div class="">
		<div class="col-md-12">
						<fieldset><legend> Data Balita</legend>
				<?php echo Form::hidden('id', $row['id']); ?>					
									  <div class="form-group row  " >
										<label for="Nama Desa" class=" control-label col-md-4 "> Nama Desa </label>
										<div class="col-md-8">
										  <select name='nama_desa' rows='5' id='nama_desa' class='select2 '   ></select> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Nama Posyandu" class=" control-label col-md-4 "> Nama Posyandu </label>
										<div class="col-md-8">
										  <select name='nama_posyandu' rows='5' id='nama_posyandu' class='select2 '   ></select> 
										 </div> 
										 
									  </div> <?php echo Form::hidden('nama_bidan', $row['nama_bidan']); ?>					
									  <div class="form-group row  " >
										<label for="Nama Balita" class=" control-label col-md-4 "> Nama Balita </label>
										<div class="col-md-8">
										  <input  type='text' name='nama_balita' id='nama_balita' value='<?php echo e($row['nama_balita']); ?>' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Tanggal Lahir" class=" control-label col-md-4 "> Tanggal Lahir </label>
										<div class="col-md-8">
										  <div class="form-row">
                                                  <input type="hidden" name="tanggal_lahir" id="tanggal_lahir">
                                              <div class="col">
                                                <select name="tanggal" id="tanggal" class="form-control form-control-sm">
                                                  <option value="">Tanggal</option>
                                                  <?php for($i = 1; $i <= 31; $i++): ?>
                                                    <option value="<?php echo e($i); ?>" <?php echo e((old('tanggal', date('j', strtotime($row['tanggal_lahir']))) == $i) ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                                  <?php endfor; ?>
                                                </select>
                                              </div> -
                                            
                                              <div class="col">
                                                <?php
                                                  $bulanIndo = [
                                                1 => 'Januari',
                                                2 => 'Februari',
                                                3 => 'Maret',
                                                4 => 'April',
                                                5 => 'Mei',
                                                6 => 'Juni',
                                                7 => 'Juli',
                                                8 => 'Agustus',
                                                9 => 'September',
                                                10 => 'Oktober',
                                                11 => 'November',
                                                12 => 'Desember'
                                              ];
                                              ?>
                                              
                                             <select name="bulan" id="bulan" class="form-control form-control-sm">
                                              <option value="">Bulan</option>
                                              <?php for($i = 1; $i <= 12; $i++): ?>
                                                <option value="<?php echo e($i); ?>" <?php echo e((old('bulan', date('n', strtotime($row['tanggal_lahir']))) == $i) ? 'selected' : ''); ?>>
                                                  <?php echo e($bulanIndo[$i]); ?>

                                                </option>
                                              <?php endfor; ?>
                                            </select>
                                              </div> -
                                            
                                              <div class="col">
                                                <select name="tahun" id="tahun" class="form-control form-control-sm">
                                                  <option value="">Tahun</option>
                                                  <?php for($i = date('Y'); $i >= 1900; $i--): ?>
                                                    <option value="<?php echo e($i); ?>" <?php echo e((old('tahun', date('Y', strtotime($row['tanggal_lahir']))) == $i) ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                                  <?php endfor; ?>
                                                </select>
                                              </div>
                                            </div>
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Jenis Kelamin" class=" control-label col-md-4 "> Jenis Kelamin </label>
										<div class="col-md-8">
										    
										    <input type='radio' name='jenis_kelamin' value ='laki-laki' required <?php if($row['jenis_kelamin'] == 'laki-laki'): ?> checked="checked" <?php endif; ?> class="filled-in" id="laki-laki">  <label for="laki-laki"> Laki-laki </label>  
                                            <input type='radio' name='jenis_kelamin' value ='perempuan' required <?php if($row['jenis_kelamin'] == 'perempuan'): ?> checked="checked" <?php endif; ?> class="filled-in" id="perempuan">  <label for="perempuan"> perempuan </label>
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Umur Balita" class=" control-label col-md-4 "> Umur Balita *<small>(Bulan)</small> </label>
										<div class="col-md-8">
										  <input  type='text' name='umur_balita' id='umur_balita' value='<?php echo e($row['umur_balita']); ?>' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Berat Balita" class=" control-label col-md-4 "> Berat Balita *<small>(Kg)</small></label>
										<div class="col-md-8">
										  <input  type='text' name='berat_balita' id='berat_balita' value='<?php echo e($row['berat_balita']); ?>' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Tinggi Badan Balita" class=" control-label col-md-4 "> Tinggi Badan Balita *<small>(Cm)</small></label>
										<div class="col-md-8">
										  <input  type='text' name='tinggi_badan_balita' id='tinggi_badan_balita' value='<?php echo e($row['tinggi_badan_balita']); ?>' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> <?php echo Form::hidden('bbu', $row['bbu']); ?><?php echo Form::hidden('pbu', $row['pbu']); ?><?php echo Form::hidden('bbpb', $row['bbpb']); ?><?php echo Form::hidden('kategori_balita', $row['kategori_balita']); ?></fieldset></div>

	</div>
	
	<input type="hidden" name="action_task" value="save" />
	<?php echo Form::close(); ?>

	</div>
</div>
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		
		$("#nama_desa").jCombo("<?php echo url('databalita/comboselect?filter=data_desa:nama_desa:nama_desa'); ?>",
		{  selected_value : '<?php echo e($row["nama_desa"]); ?>' });
		
		$("#nama_posyandu").jCombo("<?php echo url('databalita/comboselect?filter=posyandu:nama_posyandu:nama_posyandu'); ?>",
		{  selected_value : '<?php echo e($row["nama_posyandu"]); ?>' });
		 	
		 	 

		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '<?php echo e(url("databalita/removefiles?file=")); ?>'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});	
		
		
		
	});
	</script>
	<script>
      function hitungUmur() {
        const tgl = document.getElementById('tanggal').value;
        const bln = document.getElementById('bulan').value;
        const thn = document.getElementById('tahun').value;
    
        if (tgl && bln && thn) {
          const tanggalLahir = new Date(thn, bln - 1, tgl);
          const hariIni = new Date();
    
          let tahun = hariIni.getFullYear() - tanggalLahir.getFullYear();
          let bulan = hariIni.getMonth() - tanggalLahir.getMonth();
          let hari = hariIni.getDate() - tanggalLahir.getDate();
    
          // Penyesuaian jika tanggal hari belum lewat dalam bulan ini
          if (hari < 0) {
            bulan -= 1;
          }
    
          let umurDalamBulan = tahun * 12 + bulan;
    
          // Pastikan umur tidak negatif
          if (umurDalamBulan < 0) umurDalamBulan = 0;
    
          document.getElementById('umur_balita').value = umurDalamBulan;
        }
      }
    
      document.addEventListener('DOMContentLoaded', function () {
        ['tanggal', 'bulan', 'tahun'].forEach(function (id) {
          const el = document.getElementById(id);
          if (el) {
            el.addEventListener('change', hitungUmur);
          }
        });
    
        hitungUmur();
      });
    </script>
        
    <script>
      function updateTanggalLahir() {
        const tgl = document.getElementById('tanggal').value.padStart(2, '0');
        const bln = document.getElementById('bulan').value.padStart(2, '0');
        const thn = document.getElementById('tahun').value;
    
        if (tgl && bln && thn) {
          const tanggalLahirFormatted = `${tgl}-${bln}-${thn}`;
          document.getElementById('tanggal_lahir').value = tanggalLahirFormatted;
        } else {
          document.getElementById('tanggal_lahir').value = '';
        }
      }
    
      document.addEventListener('DOMContentLoaded', function () {
        ['tanggal', 'bulan', 'tahun'].forEach(function (id) {
          const el = document.getElementById(id);
          if (el) {
            el.addEventListener('change', updateTanggalLahir);
          }
        });
    
        updateTanggalLahir(); // Jalankan saat halaman pertama dimuat
      });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/benuadi1/app_sibalita/resources/views/databalita/form.blade.php ENDPATH**/ ?>